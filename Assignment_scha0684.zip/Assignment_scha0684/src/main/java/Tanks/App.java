/*
 * This function is the main class for the game. It handles the game logic, including the game loop, terrain generation, tank movement, tank firing, and parachute deployment.
 * This function mainly serves and handels whatever goes on the main game screen (mainly terrain related and other game loop)
 */

package Tanks;
import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PGraphics;
import processing.event.MouseEvent;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


public class App extends PApplet {
    public Loading loadingScreen;
    public PImage terrain;
    public boolean isPlaying = true;
    public int foregroundColor;
    public static final int CELLSIZE = 32; //8;
    public static final int CELLHEIGHT = 32;
    public static final int CELLAVG = 32;
    public PImage backgroundImg;
    public PImage treeImg;
    public char[][] map;
    public List<int[]> heightsList = new ArrayList<>();
    public List<Integer> xValues = new ArrayList<>();
    public static final int TOPBAR = 0;
    public String currentfile;
    public List <Tank> tanks = new ArrayList<Tank>();
    public List<int[]> treeCoordinates; 
    public List <Tank> impactedTanks = new ArrayList<Tank>();
    public static int WIDTH = 864; //CELLSIZE*BOARD_WIDTH;
    public static int HEIGHT = 640; //BOARD_HEIGHT*CELLSIZE+TOPBAR;
    public static final int BOARD_WIDTH = WIDTH/CELLSIZE;
    public static final int BOARD_HEIGHT = 20;
    public static final int INITIAL_PARACHUTES = 1;
    public float projectileX;
    public float projectileY;
    public float speed = 100;
    public static final int FPS = 60;
    public String configPath;
    public static Random random = new Random();
    private boolean mapPrinted = false;
    public int currentTime = 0; 
    public int startTime = millis(); 
    public boolean explosion = false;
    public boolean parachuteDeployed = false;
    public int tankturnCounter = 0;
    public boolean tankinAdjusting = true;
    public Features features;
    public int wind;
    public Level level = new Level(this);
    public boolean isgameover = false;
    public boolean helperscreen = false;
    public boolean gameStarted = false;
    public long turnStartTime = 0;
    public int fuelcount = 0;




    public App() {
        this.configPath = "config.json";
    }
    @Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }
    

    @Override
    public void setup() {
        frameRate(FPS);
        startGame();
        
    }
    

    /**
    * This function is used to start a new game. It resets all the game variables, 
    * clears any existing game data, and initializes the terrain and tanks for the new game.
    * It also sets up the wind and other game features, and displays the loading screen.
    */
    public void startGame() {
        heightsList.clear();
        xValues.clear();
        tanks.clear();
        impactedTanks.clear();
        isPlaying = true;
        projectileX = 0;
        projectileY = 0;
        speed = 100;
        foregroundColor = 0; 
        mapPrinted = false;
        currentTime = 0;
        startTime = millis();
        explosion = false;
        parachuteDeployed = false;
        tankturnCounter = 0;
        tankinAdjusting = true;
        wind = 0;
        currentfile = level.getCurrentLevelFile();
        initializeterrain(currentfile); 
        terrain = drawTerrain();
        Tank currentTank = tanks.get(0);
        features = new Features(this, tanks, currentTank, this);
        Random rand = new Random();
        wind = rand.nextInt(71) - 35;
        features.setWind(wind);
        loadingScreen = new Loading(this);

    }
    

    /**
    * Handles mouse press events. If the game hasn't started, it checks if the start button was clicked.
    * If the game has started, it checks if a specific area was clicked to display the helper screen.
    * @param e The mouse event.
    */
    @Override
    public void mousePressed(MouseEvent e) {
        if (!gameStarted) {
            gameStarted = loadingScreen.mouseClicked();
        } else {
            int rectangleX = 784; 
            int rectangleY = 10; 
            int rectangleWidth = 50; 
            int rectangleHeight = 28; 
            if (e.getX() >= rectangleX && e.getX() <= rectangleX + rectangleWidth &&
            e.getY() >= rectangleY && e.getY() <= rectangleY + rectangleHeight) {
            helperscreen = true;
            }
        }
    }

    public long getCurrentMillis() {
        return millis();
    }
   
    /**
    * Reads a map from a file, trims empty lines, and fills in the map array. 
    * It also fills in any empty spaces below 'X' characters and flips the map vertically (to keep the terrain organised for later in game logic)
    * @param filename The name of the file to read the map from.
    * @return The map array.
    */
    public char[][] drawMap(String filename) {
        char[][] map = new char[20][28]; 
    
        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            ListIterator<String> iterator = lines.listIterator(lines.size());
            while (iterator.hasPrevious()) {
                String line = iterator.previous();
                if (line.trim().isEmpty()) {
                    iterator.remove();
                } else {
                    break;
                }
            }

            // Fill the map array with the characters from the file
            for (int y = 0; y < lines.size() && y < 20; y++) {
                String line = lines.get(y);
                for (int x = 0; x < line.length() && x < 28; x++) {
                    char c = line.charAt(x);
                    map[y][x] = c; 
                }
            }
            
            // Fill in any empty spaces below 'X' characters
            for (int x = 0; x < 28; x++) {
                boolean fill = false;
                for (int y = 0; y < 20; y++) {
                    if (map[y][x] == 'X') {
                        fill = true;
                    }
                    if (fill) {
                        for (int fillY = y; fillY < 20; fillY++) {
                            map[fillY][x] = 'X';
                        }
                        break;
                    }
                }
            }
    
            // Flip the map vertically
            for (int y = 0; y < 10; y++) {
                char[] temp = map[y];
                map[y] = map[19 - y];
                map[19 - y] = temp;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }
        
    
    /**
    * Reads a configuration file and returns a map of settings for a given layout. 
    * It includes level-specific settings and player color settings.
    * @param layoutFilename The name of the layout file to get the settings for.
    * @return A map of settings for the given layout.
    */
    public Map<String, String> getConfigSettings(String layoutFilename) {
        JSONParser parser = new JSONParser();
        Map<String, String> settings = new HashMap<>();

        // Read the configuration file
        try {
            org.json.simple.JSONObject config = (org.json.simple.JSONObject) parser.parse(new FileReader("config.json"));
            org.json.simple.JSONArray levels = (org.json.simple.JSONArray) config.get("levels");
    
            for (int i = 0; i < levels.size(); i++) {
                org.json.simple.JSONObject levelObject = (org.json.simple.JSONObject) levels.get(i);
                String layout = (String) levelObject.get("layout");
                // sorting out settings with the 'key' values
                if (layout.equals(layoutFilename)) {
                    settings.put("background", (String) levelObject.get("background"));
                    settings.put("foreground-colour", (String) levelObject.get("foreground-colour"));
                    settings.put("trees", (String) levelObject.get("trees"));
                    break;
                }
            }
    
            org.json.simple.JSONObject playerColours = (org.json.simple.JSONObject) config.get("player_colours");
            for (Object key : playerColours.keySet()) {
                settings.put("player_colour_" + key, (String) playerColours.get(key));
            }
    
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    
        return settings;
    }


    /**
    * Loads and draws the background image for the current level based on the configuration settings.
    * @param currentfile The name of the current level file.
    */
    public void drawbackground(String currentfile){
        Map<String, String> settings = getConfigSettings(currentfile);
        PImage backgroundImg = loadImage("src/main/resources/Tanks/" + settings.get("background"));
    }


    /**
    * Loads the map from a file, initializes the terrain, and sets up the game objects such as trees and tanks.
    * Responsible to draw and initialize all the variables in the main game loop.
    * @param currentfile The name of the current level file.
    */
    public void initializeterrain(String currentfile){
        map = drawMap(currentfile);
        // Get the images of the components based on the requirements from config file
        if (!mapPrinted) {
            Map<String, String> settings = getConfigSettings(currentfile);
            backgroundImg = loadImage("src/main/resources/Tanks/" + settings.get("background"));
            treeImg = loadImage("src/main/resources/Tanks/" + settings.get("trees"));

            String[] rgb = settings.get("foreground-colour").split(",");
            int r = Integer.parseInt(rgb[0]);
            int g = Integer.parseInt(rgb[1]);
            int b = Integer.parseInt(rgb[2]);
            foregroundColor = color(r, g, b);
            Queue<Integer> queueX = new LinkedList<>();
            Queue<Integer> queueY = new LinkedList<>();

            // Create a list to store the heights and corresponding x values
            treeCoordinates = new ArrayList<>();


            // First, draw all the terrain and store the heights and x values
            for (int x = 0; x < map[0].length; x++) {
                for (int y = map.length - 1; y >= 0; y--) {
                    if (map[y][x] == 'X') {
                        queueX.add(x * CELLSIZE);
                        queueY.add((map.length - 1 - y) * CELLSIZE);
                        break; // Break the loop once the topmost 'X' cell is found
                    }
                    else if (map[y][x] == 'T') {
                        // Store the tree coordinates
                        treeCoordinates.add(new int[]{(x-1) * CELLSIZE,(map.length - 1 - y) * CELLSIZE});
                    }

                }

                // If there are two 'X' cells in the queue, calculate the heights and store them
                // Handeling the smoothing process here for the terrain
                if (queueX.size() == 2) {
                    int currentX = queueX.poll();
                    int currentY = queueY.poll();
                    int nextY1 = queueY.peek();
                    int[] y1Coordinates = new int[32];
                    int[] y2Coordinates = new int[32];
                    for (int i = 0; i < 32; i++) {
                        y1Coordinates[i] = currentY;
                        y2Coordinates[i] = nextY1;
                    }
                    int [] height = calculateHeights(y1Coordinates, y2Coordinates);
                    heightsList.add(height);
                    xValues.add(currentX);

                }
            }
            // Handle the last 'X' cell
            if (!queueX.isEmpty()) {
                int currentX = queueX.poll();
                int currentY = queueY.poll();

                int[] y1Coordinates = new int[32];
                int[] y2Coordinates = new int[32];

                for (int i = 0; i < 32; i++) {
                    y1Coordinates[i] = currentY;
                    y2Coordinates[i] = currentY; // Use currentY for both y1Coordinates and y2Coordinates
                }

                int[] height = calculateHeights(y1Coordinates, y2Coordinates);

                // Store the height and x value
                heightsList.add(height);
                xValues.add(currentX);
            }

            for (int i = 0; i < heightsList.size() - 1; i++) { // Subtract 1 to avoid ArrayIndexOutOfBoundsException
                int currentX = xValues.get(i);
                boolean tree = false;
                for (int[] coordinates : treeCoordinates) {
                    if (currentX == coordinates[0]) {
                        tree = true;
                        break;
                    }
                }
                int[] y1Coordinates = heightsList.get(i);
                int[] y2Coordinates = heightsList.get(i + 1); // Always use the next height
                int[] newHeight = calculateHeights(y1Coordinates, y2Coordinates); 
                heightsList.set(i, newHeight); // Replace the existing list at index i with newHeight
                }
            initializeTank(currentfile);
            mapPrinted = true;
            
        }

    }


    /**
    * Calculates the average height for each 32-pixel wide column of the terrain, using two input arrays.
    * The function takes two arrays and give out what would be the average height of the terrain at that point in that particular first array.
    * @param y1 The first array of heights.
    * @param y2 The second array of heights.
    * @return An array of average heights for each 32-pixel wide column of the terrain.
    */
    public int[] calculateHeights(int[] y1, int[] y2) {
        int[] heights = new int[32];
        for (int i = 0; i < heights.length; i++) {
            int sum = 0;
            int count = 0;
            for (int j = i; j < y1.length && count < 32; j++) {
                sum += y1[j];
                count++;
            }
            for (int j = 0; count < 32; j++) {
                sum += y2[j];
                count++;
            }
            heights[i] = sum / 32;
        }
    
        return heights;
    }
        
    
    /**
    * Creates a terrain image by drawing the background and then drawing each column of the terrain.
    * It also places trees at specified coordinates.
    * In this we using PGraphics to draw the terrain and then return the image of the terrain.
    * This is done so we ensure not much of the processing power is used in drawing the terrain every single time draw tick is called.
    * Rather we draw the terrain (updated) once and use it image to display the terrain.
    */
    public PImage drawTerrain() {
        PGraphics terrainGraphics = createGraphics(width, height);
        terrainGraphics.beginDraw();
        terrainGraphics.image(backgroundImg, 0, 0);
        
        // Draw the terrain
        for (int i = 0; i < heightsList.size(); i++) {
            int currentX = xValues.get(i);
            boolean tree = false;
            for (int[] coordinates : treeCoordinates) {
                if (currentX == coordinates[0]) {
                    tree = true;
                    break;
                }
            }

            int[] height = heightsList.get(i); 
            terrainGraphics.stroke(foregroundColor);
            int width = height.length;
    
            for (int j = 0; j < width; j++) {
                if (tree) {
                    terrainGraphics.image(treeImg, currentX, height[15]-32, CELLSIZE, CELLSIZE);
                }
                terrainGraphics.line(currentX + j, height[j], currentX + j, 640);
            }
        }

        terrainGraphics.endDraw();
        mapPrinted = true;
        return terrainGraphics.get();
    }

    
    /**
    * Main game loop. Handles game states such as loading screen, helper screen, and gameplay. 
    * It also handles level progression, background and terrain drawing, tank turns, parachute deployment, 
    * tank firing, score storing, and leaderboard display.
    */
    @Override
    public void draw() {

        // Check if the game is over and display the leaderboard
        if (isgameover) {
            level.drawLeaderboard();
            handleTankTurns();
            for(int i = 0; i < tanks.size(); i++){
                tanks.get(i).setScore(0);
            }
            return;
        }
    
        // if the game is not started, display the loading screen
        if (!gameStarted) {
            loadingScreen.draw();
            keyboardcontrols(tankturnCounter);
            return;
        }
    
        // Used to display the help box
        if (helperscreen) {
            features.drawHelperScreen();
            return;
        }
    
        // In every tick check when to progress the level and handel scoring process
        if (checklevelover()) {
            level.progressLevel();
        }
    
        // Rest of the code to draw terrain, check tank turns, handle parachute animations, and tank firing. 
        drawBackgroundAndTerrain();
        handleTankTurns();
        checkParachuteDeployment();
        handleParachuteDeployment();
        Tank currentTank = tanks.get(tankturnCounter);
        handleTankFiring(currentTank);
        level.storeScores();
    }


   /**
    * Checks if the level is over by verifying if only one tank is left in the game.
    */ 
    public boolean checklevelover(){
        if(tanks.size() == 1){
            return true;
        }
        return false;
    }

   /**
    * Helper function to help us draw background and get the image of the terrain.
    */ 
    public void drawBackgroundAndTerrain() {
        drawbackground(currentfile);
        image(terrain, 0, 0);
        drawTanks();
    }


    /**
     * Draws the tanks on the terrain and updates the tank's position and health.
     * Gets the tank position and update it based on keyboard inputs
     */
    public void handleTankTurns() {
        
        if(tankturnCounter > tanks.size()-1){
            tankturnCounter = 0;
        }
        Tank tank = tanks.get(tankturnCounter);
        keyboardcontrols(tankturnCounter);
        features.draw(tank);
        drawTurnIndicator(tank);
        
    }
    

    /**
    * Draw the arrow which gives which tank turn it is.
    * @param tank The tank whose turn it is.
    */
    public void drawTurnIndicator(Tank tank) {
        int x = tank.getXtank();
        int y = tank.getYtank() - 50; 
        int arrowSize = 20; 
    
        int x1 = x, y1 = y + arrowSize;
        int x2 = x - arrowSize / 2, y2 = y;
        int x3 = x + arrowSize / 2, y3 = y;
    
        fill(255, 0, 0); 
            if (millis() - turnStartTime < 2000) { // make sure we flash it for 2 seconds.
            if ((millis() / 500) % 2 == 0) { // Flash twice per second
                triangle(x1, y1, x2, y2, x3, y3);
            }
            
        }

        if (millis() - turnStartTime == 2000) { 
            turnStartTime = 0;
        }
    
        y += Math.sin(millis() / 200.0) * 10; 
    }


    /**
    * Gets the terrain height at the given point and check if tank is still on the terrain or parachute needs to be deployed.
    */
    public void checkParachuteDeployment() {
        for(Tank t: tanks){

            // Remove tank if it's not on the ground
            if (t.getYtank() > 630) {
                handleExplosion(t);
                if(tankturnCounter == tanks.size()-1){
                tankturnCounter--;
                }
                tanks.remove(t);
                return;
            }
            if(t.getYtank() < getTerrainHeightAtX(t.getXtank(), heightsList, xValues)-8){
                parachuteDeployed = true;
            }
        }
    }
    

    /**
    * This function handles all the patachute deployment and tank landing on the terrain.
    * It handles the parachite animations, the falling speed, and the tank health and power.
    */
    public void handleParachuteDeployment() {
        if (!parachuteDeployed) {
            return;
        }
    
        for (int i = 0; i < impactedTanks.size(); i++) {
            Tank t = impactedTanks.get(i);
            int terrainHeight = getTerrainHeightAtX(t.getXtank(), heightsList, xValues) - 8;
    
            // Handle parachute deployment
            if (t.getYtank() != terrainHeight && t.getParachutes() > 0) {
                handleTankWithParachute(t, terrainHeight, i);
                continue;
            }
    
            // Handle tank falling without parachute
            if (t.getYtank() != terrainHeight && t.getParachutes() == 0) {
                handleTankWithoutParachute(t, terrainHeight, i);
                continue;
            }
    
            // Remove tank from impactedTanks list if it has landed on the ground
            if (t.getYtank() == terrainHeight) {
                impactedTanks.remove(i);
                i--; // Decrement the index to account for the removed tank
            }
    
            // Reset parachuteDeployed flag if all impacted tanks have been processed
            if (i == impactedTanks.size() - 1) {
                parachuteDeployed = false;
            }
        }
    }
    
    /**
     * Helper function assisting condition if tank has parachute and is still in the air.
     * @param t The tank that is falling.
     * @param terrainHeight The height of the terrain.
     * @param i The index of the tank in the impactedTanks list.
     */
    public void handleTankWithParachute(Tank t, int terrainHeight, int i) {
        t.isparachuteopen = true;
        t.setYtank(t.getYtank() + 1);
        tankinAdjusting = true;
        if (t.getYtank() == terrainHeight - 1) {
            t.setParachutes(t.getParachutes() - 1);
            impactedTanks.remove(i);
            i--; // Decrement the index to account for the removed tank
        }
    }

    /**
     * Helper function assisting condition if tank has no parachute and is still in the air.
     * @param t The tank that is falling.
     * @param terrainHeight The height of the terrain.
     * @param i The index of the tank in the impactedTanks list.
     */
    public void handleTankWithoutParachute(Tank t, int terrainHeight, int i) {
        if (!t.isFalling()) {
            t.setInitialY(t.getYtank()); // Set the initial Y position when the tank starts falling
            t.setFalling(true);
        }
    
        int oldY = t.getYtank();
        t.setYtank(t.getYtank() + 2);
        tankinAdjusting = true;
    
        if (t.getYtank() >= terrainHeight - 1) {
            int newY = t.getYtank();
            int fallDamage = newY - t.getInitialY();
            int newHealth = t.getHealth() - fallDamage;
    
            if (newHealth <= 0) {
                t.setHealth(0); // Set health to 0 if it falls to negative
                t.printExplosion(this, t.getXtank(), t.getYtank());     
                tanks.remove(t);
                tankturnCounter--;
            } else {
                t.setHealth(newHealth); // Calculate the fall damage based on the difference between the final and initial Y positions
                if (t.getHealth() < t.getPower()) {
                    t.setPower(t.getHealth());
                }
            }
    
            impactedTanks.remove(i);
            i--; // Decrement the index to account for the removed tank
            t.setFalling(false); // Reset the falling state when the tank hits the ground
        }
    }
    
        
    /**
     * Handles the logic for when a tank fires a projectile.
     * @param tank The tank that is firing.
     */
    public void handleTankFiring(Tank tank) {
        if (tank.isTankfired() && !explosion) {
            tank.updateProjectile(this, wind);
        }

        if (isProjectileOutOfBounds(tank)) {
            tank.setProjectileX(0);
            tank.setProjectileY(0);
            resetTankTurn(tank);
            return;
        }

        if (isProjectileHitTerrain(tank)) {
            handleProjectileTerrainCollision(tank);
        }
    }

    /**
     * Checks if the projectile is out of bounds.
     * @param tank The tank that fired the projectile.
     * @return True if the projectile is out of bounds, false otherwise.
     */
    private boolean isProjectileOutOfBounds(Tank tank) {
        return tank.getProjectileX() < 0 || tank.getProjectileX() > WIDTH || tank.getProjectileY() > HEIGHT;
    }

    /**
     * Resets the turn of the tank.
     * @param tank The tank whose turn is being reset.
     */
    private void resetTankTurn(Tank tank) {
        tank.setTankfired(false);
        tankturnCounter++;
        turnStartTime = millis(); // Record the start time of the new turn
    }

    /**
     * Checks if the projectile hit the terrain.
     * @param tank The tank that fired the projectile.
     * @return True if the projectile hit the terrain, false otherwise.
     */
    private boolean isProjectileHitTerrain(Tank tank) {
        return (int) tank.getProjectileY() > getTerrainHeightAtX((int) tank.getProjectileX(), heightsList, xValues);
    }

    /**
     * Handles the logic for when a projectile hits the terrain.
     * @param tank The tank that fired the projectile
     */
    public void handleProjectileTerrainCollision(Tank tank) {
        if (tank.getExplosionCounter() < 5) {
            handleExplosion(tank);
        } else {
            handleCollision(tank);
        }
    }

    /**
     * Handles the logic for when a projectile explodes.
     * @param tank The tank that fired the projectile.
     */
    private void handleExplosion(Tank tank) {
        tank.printExplosion(this, tank.getProjectileX(), tank.getProjectileY());
        explosion = true;
        tank.explosionCounter++;
        turnStartTime = millis();
    }

    /**
     * Handles the logic for when a projectile collides with the terrain.
     * @param tank The tank that fired the projectile.
     */
    public void handleCollision(Tank tank) {
        resetTankTurn(tank);
        explosion = false;
        tank.explosionCounter = 0;
        handleImpactedTanks(tank);
        collisionUpdate((int) tank.getProjectileX(), (int) tank.getProjectileY(), heightsList);

    }

    /**
     * Handles the logic for when tanks are impacted by a projectile.
     * @param tank The tank that fired the projectile.
     */
    public void handleImpactedTanks(Tank tank) {
        Iterator<Tank> iterator = tanks.iterator();
        while (iterator.hasNext()) {
            Tank otherTank = iterator.next();
            double distance = calculateDistance(tank, otherTank);

            if (Math.abs(otherTank.getXtank() - tank.getProjectileX()) <= 30) {
                impactedTanks.add(otherTank);
                calculateAndApplyDamage(tank, otherTank, distance);
                if (otherTank.getHealth() <= 0) {
                    iterator.remove();
                }
            }
        }
    }

    /**
     * Calculates the distance between two tanks.
     * @param tank The tank that fired the projectile.
     * @param otherTank The tank that is being impacted.
     * @return The distance between the two tanks.
     */
    public double calculateDistance(Tank tank, Tank otherTank) {
        return Math.sqrt(Math.pow(otherTank.getXtank() - tank.getProjectileX(), 2) + Math.pow(otherTank.getYtank() - tank.getProjectileY(), 2));
    }

    /**
     * Calculates the damage dealt to a tank by a projectile and applies it.
     * @param tank The tank that fired the projectile.
     * @param otherTank The tank that is being impacted.
     * @param distance The distance between the two tanks.
     */
    public void calculateAndApplyDamage(Tank tank, Tank otherTank, double distance) {
        int damage = (int) ((30 - distance) * 2);
        damage = Math.max(damage, 0);
        int newHealth = Math.min(otherTank.getHealth() - damage, 100);
        otherTank.setHealth(newHealth);
        if (otherTank != tank) {
            tank.setScore(tank.getScore() + damage);
        }
        if (otherTank.getHealth() < otherTank.getPower()) {
            otherTank.setPower(otherTank.getHealth());
        }
    }

    /**
     * Updates the collision after the projectile impact.
     * @param x The x-coordinate of the collision.
     * @param y The y-coordinate of the collision.
     * @param heightsList The list of heights.
     */
    public void collisionUpdate(int x, int y, List<int[]> heightsList) {
        int radius = 30;
    
        for (int i = x - radius; i <= x + radius; i++) {
            if (i >= 0 && i < heightsList.size() * 32) {
                int arrayIndex = i / 32; 
                int valueIndex = i % 32; 
    
                // Calculate the distance from the point of collision
                int distance = Math.abs(x - i);
    
                // Calculate the new height based on the distance from the point of collision
                int newHeight = y + (int) Math.sqrt(Math.pow(radius, 2) - Math.pow(distance, 2));
    
                if (newHeight > heightsList.get(arrayIndex)[valueIndex]) {
                    heightsList.get(arrayIndex)[valueIndex] = newHeight;
                }
            }
        }
        terrain = drawTerrain(); 
    }
    
    /**
     * Handles the keyboard controls for the game. This includes moving the tank, adjusting the power and angle of the shot,
    * @param tankturnCounter1 The counter for the tank turn.
    */

    public void keyboardcontrols(int tankturnCounter1){
        loadingScreen.keyPressed();
        Tank tank = tanks.get(tankturnCounter1);
        tank.decrementKeyCounters();
        if (!gameStarted){
            gameStarted = loadingScreen.keyPressed();
        }
        else{
        
        if (isPlaying && !tanks.isEmpty() && !tank.isTankfired()) {
            if (keyPressed && !tanks.isEmpty()) {
            
                if ((keyCode == LEFT || keyCode == RIGHT) && tank.getFuel() > 0) {
                    fuelcount++;
                
                    int tank_current_possition_x = tank.getXtank();
                    int moveAmount = Math.round(60.0f/frameRate); // Calculate the amount to move per frame

                    int tank_new_possition_x = keyCode == LEFT ? tank_current_possition_x - moveAmount : tank_current_possition_x + moveAmount;
                
                    // Check if the tank has reached the end of the screen
                    if (tank_new_possition_x < 0 || tank_new_possition_x > 835) {
                        return;
                    }
                
                    if (fuelcount % 2 == 0) {
                        tank.setFuel(tank.getFuel()-1);
                    }
                
                    int tank_new_possition_y = getTerrainHeightAtX(tank_new_possition_x, heightsList, xValues)-8;
                    if (tank_new_possition_y != -1) {
                        tank.setXtank(tank_new_possition_x);
                        tank.setYtank(tank_new_possition_y);
                    }
                }
            

                if(key == 'w'){
                    // Increase power, but not more than the remaining health of the tank
                    if (tank.getPower() < tank.getHealth()) {
                        tank.setPower(tank.getPower() + 1);
                    }
                }
                
                if(key == 's'){
                    // Decrease power, but not less than 0
                    if (tank.getPower() > 0) {
                        tank.setPower(tank.getPower() - 1);
                    }
                }

                
                if(key == 'r' && tank.rKeyCounter == 0){
                    if(isgameover){
                        level.currentLevel = 0; 
                        isgameover = false;
                        startGame();
                        
                    }

                    int repairAmount = 20;
                    if (tank.score >= repairAmount) {
                        tank.health = Math.min(tank.health + repairAmount, 100);
                        tank.score -= repairAmount;
                    }
                    tank.rKeyCounter = 50; 
                }
                
                if(key == 'f' && tank.fKeyCounter == 0){
                    int repairAmount = 10;
                    if (tank.score >= repairAmount) {
                        tank.fuel = tank.fuel + 200;
                        tank.score -= repairAmount;
                    }
                    tank.fKeyCounter = 50; 
                }
                
                if(key == 'p' && tank.pKeyCounter == 0){
                    int repairAmount = 15;
                    if (tank.score >= repairAmount) {
                        tank.parachutes = tank.parachutes + 1;
                        tank.score -= repairAmount;
                    }
                    tank.pKeyCounter = 50; 
                }
                        
        
                if (keyCode == UP) {
                    // Increase the angle by 3 radians per second
                    float angleChange = 60.0f / frameRate;
                    float newAngle = tank.getAngle() + angleChange;
                
                    // Cap the angle at 90 degrees
                    if (newAngle > 90) {
                        newAngle = 90;
                    }
                
                    tank.setAngle(newAngle);
                }
        
        
                
            if (keyCode == DOWN) {
                // Decrease the angle by 3 radians per second
                float angleChange = 60.0f / frameRate;
                float newAngle = tank.getAngle() - angleChange;
            
                // Cap the angle at -90 degrees
                if (newAngle < -90) {
                    newAngle = -90;
                }
            
                tank.setAngle(newAngle);
            }
     
        if (key == ' ') {
            tank.setTankfired(true);
            tank.setprojectilestartX(tank.getXtank()+20);
            tank.setprojectilestartY(tank.getYtank()-20);
            tank.fireProjectile(this, tank.getAngle(), tank.getturretx(), tank.getturrety(), tank.getPower());
            updatewind();
            features.setWind(wind);
        }

    }
}}}




    public void updatewind() {
        Random rand = new Random();
        int windChange = rand.nextInt(11) - 5; 
        wind += windChange;
        wind = Math.max(wind, -35);
        wind = Math.min(wind, 35);
    }

    /**
     * Initializes a tank.
     * @param filename The name of the file with the tank configuration.
     */
    public void initializeTank(String filename) {
        Map<String, String> settings = getConfigSettings(filename);

        // Initialize the tanks based on the map
        for (int x = 0; x < map[0].length; x++) {
            for (int y = map.length - 1; y >= 0; y--) {
                char mapCell = map[y][x];
                if (isTankCell(mapCell)) {
                    String colourKey = "player_colour_" + mapCell;
                    if (settings.containsKey(colourKey)) {
                        initializeTankAtCell(settings, colourKey, x, y);
                    }
                }
            }
        }
    }

    /**
     * Checks if a cell in the map is a tank cell.
     * @param cell The cell to check.
     * @return True if the cell is a tank cell, false otherwise.
     */
    private boolean isTankCell(char cell) {
        return cell == 'A' || cell == 'B' || cell == 'C' || cell == 'D';
    }

    /**
     * Initializes a tank at a specific cell in the map.
     * @param settings The settings for the current level.
     * @param colourKey The key for the tank's color in the settings map.
     * @param x The x-coordinate of the cell.
     * @param y The y-coordinate of the cell.
     */
    private void initializeTankAtCell(Map<String, String> settings, String colourKey, int x, int y) {
        String colour = settings.get(colourKey);
        int xCoordinate = (x)*CELLSIZE + (28/2); // Add half the width of the tank to center it in the cell
        int yCoordinate = getTerrainHeightAtX(xCoordinate, heightsList, xValues);
        Tank tank = new Tank(this, colour, xCoordinate, yCoordinate-8);
        tanks.add(tank);

        int index = tanks.size()-1;
        tank.settankindex(index);

        // If the colorScores map contains a score for this tank's color, set the tank's score to that value
        if (level.getColorScores().containsKey(colour)) {
            tank.setScore(level.getColorScores().get(colour)[0]);
            tank.settankindex(level.getColorScores().get(colour)[1]);
        }
    }


    /**
     * Draws the tanks on the terrain.
     */
    public void drawTanks() {
        for (Tank tank : tanks) {
            tank.drawTank(this, tank.getXtank(), tank.getYtank(), tank.getColor(), tank.getAngle());
        }
    }


    /**
     * Gets the terrain height at a specific x-coordinate.
     * @param x The x-coordinate.
     * @param heightsList The list of heights.
     * @param xValues The list of x-values.
     * @return The terrain height at the specified x-coordinate.
     */
    public int getTerrainHeightAtX(int x, List<int[]> heightsList, List<Integer> xValues) {
        int xIndex = x / 32; // Calculate the index of the x-coordinate
        if (xIndex < xValues.size()) {
            int[] heights = heightsList.get(xIndex);
            int heightIndex = x % 32;
            if (heightIndex < heights.length) {
                return heights[heightIndex];
            }
        }
        return -1; 
    }
            
    public static void main(String[] args) {
        PApplet.main("Tanks.App");
    }}