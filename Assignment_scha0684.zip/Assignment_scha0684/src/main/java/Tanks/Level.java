/*
 * This class in resposible for handeling the level progression for the game.
 * It also handles the storing of the scores and linking them with tank colours and players.
 * This is also reponsible to display the leaderboard at the end of the game.
 */

package Tanks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class Level {
    public int currentLevel = 0;
    private long lastUpdateTime = 0;
    public int leaderboardIndex = 0;
    private String[] levels = {"level1.txt","level2.txt","level3.txt"};
    private App app; 
    private Map<String, int[]> colorScores = new HashMap<>();
    public Level(App app) {
    this.app = app;
    }

    public String getCurrentLevelFile() {
        return levels[currentLevel];
    }

    /**
     * Progress the level by when whenever called.
     */
    public void progressLevel() {
        if (currentLevel < levels.length - 1) {
            currentLevel++;
            resetlevel();
        } else {
            app.isgameover = true;
        }
    }


    /**
     * draw the leaderboard at the end of the game.
     */
    public void drawLeaderboard() {

        // Sort the scores in descending order
        List<Map.Entry<String, int[]>> sortedEntries = new ArrayList<>(colorScores.entrySet());
        sortedEntries.sort(Map.Entry.<String, int[]>comparingByValue((a, b) -> b[0] - a[0]));

        int x = app.WIDTH / 2; 
        int y = app.HEIGHT / 2; 

        int rectWidth = 300; 
        int rectHeight = sortedEntries.size() * 40 + 130; 

        // Determine the winner and their color
        Map.Entry<String, int[]> winnerEntry = sortedEntries.get(0);
        String[] rgb = winnerEntry.getKey().split(",");
        int red = Integer.parseInt(rgb[0]);
        int green = Integer.parseInt(rgb[1]);
        int blue = Integer.parseInt(rgb[2]);

        // Set the background color of the leaderboard to a slightly transparent version of the winner's color
        app.fill(red, green, blue, 2); // The fourth argument is the alpha value
        app.noStroke(); 
        app.rect(x - rectWidth / 2, y - rectHeight / 2, rectWidth, rectHeight);

        // Display the winner's name on the leaderboard
        app.fill(0);
        app.textSize(32);
        char winnerName = (char)('A' + winnerEntry.getValue()[1]);
        app.text("Player " + winnerName + " won!!", x-140, y - rectHeight / 2 + 40); 

        // Draw the leaderboard
        app.textSize(20); 
        app.fill(255); 
        app.text("Leaderboard:", x-140, y - rectHeight / 2 + 70); 

        app.stroke(0); 
        app.line(x - rectWidth / 2, y - rectHeight / 2 + 90, x + rectWidth / 2, y - rectHeight / 2 + 90);

        // In loop go through the sorted entries and display the scores
        int i = 0;
        for (Map.Entry<String, int[]> entry : sortedEntries) {
            if (i < leaderboardIndex) {
                rgb = entry.getKey().split(",");
                red = Integer.parseInt(rgb[0]);
                green = Integer.parseInt(rgb[1]);
                blue = Integer.parseInt(rgb[2]);

                app.fill(red, green, blue);
                char playerName = (char)('A' + entry.getValue()[1]);
                app.text("Player " + playerName + ": " + entry.getValue()[0] + " points", x-140, (y - rectHeight / 2 + 110 + i * 40));
                i++;
            }
        }

        // Create a flashing "Press '-r' to play again" message
        if (app.frameCount % 60 < 30) { 
            app.textSize(15);
            app.fill(0);
            app.text("Press '-r' to play again", x-140, y + rectHeight / 2 - 10);
        }

        // Update the leaderboard index every second
        if (System.currentTimeMillis() - lastUpdateTime >= 1000) {
            leaderboardIndex++;
            lastUpdateTime = System.currentTimeMillis();
        }


    }


    /**
     * Store the scores of the tanks in the colorScores map.
     */
    public void storeScores() {
        for (Tank tank : app.tanks) { 
            int[] scoreAndIndex = new int[]{tank.getScore(), tank.gettankindex()};
            colorScores.put(tank.getColor(), scoreAndIndex); 
        }
    }


    /**
     * Reset the level when called.
     */
    public void resetlevel() {
        // Reset the game
        app.startGame();
        
    }


    /**
     * Get the colorScores map.
     * @return colorScores
     */
    public Map<String, int[]> getColorScores() {
        return colorScores;
    }

    public void setColorScores(Map<String, int[]> colorScores) {
        this.colorScores = colorScores;
    }
}