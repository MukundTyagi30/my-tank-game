/*
 * This class is responsible for the loading screen of the game.
 */

package Tanks;
import processing.core.PApplet;
import processing.core.PImage;

public class Loading {
    PApplet parent;
    int buttonX, buttonY, buttonWidth, buttonHeight;
    PImage bgImage;
    int selectedButton = 0; 

    public Loading(PApplet parent) {
        this.parent = parent;
        this.buttonWidth = 200;
        this.buttonHeight = 100;
        this.buttonX = (parent.width - buttonWidth) / 2;
        this.buttonY = (int)(parent.height * 0.65); // 10% lower
        this.bgImage = parent.loadImage("build/resources/main/Tanks/edith-life-sprite1-1.jpg");
    }

    public void draw() {
        parent.image(bgImage, 0, 0, parent.width, parent.height);
        drawButton("Start Game", buttonY, selectedButton == 0);
        drawButton("Quit Game", buttonY + buttonHeight, selectedButton == 1);
    }

    /**
     * This method is responsible for drawing the buttons on the loading screen.
     * @param text: text to be displayed on the button
     * @param y: y-coordinate of the button
     * @param selected: whether the button is selected or not
     */


    /**
     * This method is responsible for drawing the buttons on the loading screen.
     * @param text: text to be displayed on the button
     * @param y: y-coordinate of the button
     * @param selected: whether the button is selected or not
     */
    private void drawButton(String text, int y, boolean selected) {
        parent.fill(128, 128, 128, 0); 
        if (selected) {
            parent.stroke(180); 
            parent.strokeWeight(5); 
        } else {
            parent.noStroke(); 
        }
        int smallerButtonWidth = buttonWidth - 10;
        int smallerButtonHeight = buttonHeight - 20;
        parent.rect(buttonX+20, y, smallerButtonWidth, smallerButtonHeight, 40); 
        parent.fill(180); 
        parent.textSize(32);
        parent.text(text, buttonX + 30, y + 50);
    }

    /**
     * This method is responsible for checking if the mouse is clicked on the button.
     */
    public boolean mouseClicked() {
        if (parent.mouseX >= buttonX && parent.mouseX <= buttonX + buttonWidth) {
            if (parent.mouseY >= buttonY && parent.mouseY <= buttonY + buttonHeight) {
                return true; 
            } else if (parent.mouseY >= buttonY + buttonHeight + 20 && parent.mouseY <= buttonY + 2 * buttonHeight + 20) {
                System.exit(0); 
            }
        }
        return false;
    }

    /**
     * This method is responsible for checking if the key is pressed on the button.
     */
    public boolean keyPressed() {
        if (parent.keyCode == PApplet.UP) {
            selectedButton = 0;
        } else if (parent.keyCode == PApplet.DOWN) {
            selectedButton = 1;
        } else if (parent.keyCode == PApplet.ENTER || parent.keyCode == PApplet.RETURN) {
            if (selectedButton == 0) {
                return true;
            } else if (selectedButton == 1) {
                System.exit(0); 
                
            }
        }
        return false;
    }
}    