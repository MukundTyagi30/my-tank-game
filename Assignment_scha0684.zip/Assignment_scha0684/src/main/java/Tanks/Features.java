/*
 * This class in responsible for us to draw all the ui elements in the game
 * It handles all the decisions made in gui and reponsible to update them in accordance with the game state
 * Appart from required Gui requirements, I have also made a help box which when clicked will provide with all the 
 * shortcuts and power-ups available in the game and how to avail them.
 */

package Tanks;
import java.util.ArrayList;
import java.util.List;
import processing.core.PApplet;
import processing.core.PImage;
import processing.event.MouseEvent;

public class Features {
    public List<Tank> tanks;
    public ArrayList<Tank> allTanks; 
    public PApplet parent;
    public int scoreboardX;
    public int scoreboardY;
    public int scoreboardWidth;
    public int scoreboardHeight;
    public Tank currentTank;
    public int wind;
    public boolean isHelpBoxOpen = false;
    public App app;

    
    public Features(PApplet parent, List<Tank> tanks, Tank currentTank, App app) {
        this.parent = parent;
        this.tanks = tanks;
        this.scoreboardX = parent.width - 200; 
        this.scoreboardY = 50; 
        this.scoreboardWidth = 150; 
        this.scoreboardHeight = parent.height - 100; 
        this.currentTank = currentTank;
        this.allTanks = new ArrayList<>(tanks); 
        this.wind = wind;
        this.app = app;
        app.registerMethod("mouseEvent", this); // Register this class to receive mouse events
    }


    /**
     * Draws the game features including the scoreboard, the current player, and the helper screen if it's open.
     */
    public void draw(Tank currentTank) {
        drawScoreboard();
        if (tanks.contains(currentTank)) {
            drawCurrentPlayer(currentTank);
        }
        if (isHelpBoxOpen) {
            drawHelperScreen();
        }
    }


    /**
     * Sets the wind value.
     * @param wind The wind value to set.
     */
    public void setWind(int wind) {
        this.wind = wind;
    }


    /**
     * Draws the current player's information including the health, fuel, parachute, power, and the player's turn.
     * @param currentTank The current player.
     */
    public void drawCurrentPlayer(Tank currentTank) {
        parent.fill(0); 
        parent.textSize(20); 
        String player = "Player " + (char)('A' + tanks.indexOf(currentTank));
        parent.text(player + "'s turn", 10, 30); 
    
        
        PImage fuelIcon = parent.loadImage("build/resources/main/Tanks/fuel.png");
        fuelIcon.resize(0, 25); 
        parent.image(fuelIcon, 10, 50);
        parent.textSize(18); 
        parent.text(String.valueOf(currentTank.getFuel()), 40, 70); // Draw the fuel value
    
        // Load and draw the parachute icon and value
        PImage parachuteIcon = parent.loadImage("build/resources/main/Tanks/parachute.png");
        parachuteIcon.resize(0, 25); 
        parent.image(parachuteIcon, 10, 90);
        parent.textSize(18); 
        parent.text(String.valueOf(currentTank.getParachutes()), 40, 110); 
        
        int oldFill = parent.g.fillColor;
        int oldStroke = parent.g.strokeColor;
    
        // Draw the health bar
        int healthBarY = 20;
        int healthBarX = parent.width / 2 - 30;
        parent.noFill(); 
        parent.rect(healthBarX, healthBarY, 100, 20); 
        String[] rgb = currentTank.getColor().split(",");
        int red = Integer.parseInt(rgb[0]);
        int green = Integer.parseInt(rgb[1]);
        int blue = Integer.parseInt(rgb[2]);
        parent.fill(red, green, blue); 
        parent.rect(healthBarX, healthBarY, currentTank.getHealth(), 20); // Draw the filled part of the health bar
        parent.fill(0); 
        parent.textSize(18); 
        parent.text("Health:", healthBarX - 70, healthBarY + 15); 
        parent.text(currentTank.getHealth(), healthBarX + 110, healthBarY + 15); 
    
        // Draw the power indicator
        parent.stroke(255, 0, 0); // Set the indicator stroke color to red
        parent.line(healthBarX + currentTank.getPower(), healthBarY, healthBarX + currentTank.getPower(), healthBarY + 20); // Draw the power indicator line
        parent.fill(0); 
        parent.text("Power:", healthBarX - 70, healthBarY + 40); 
        parent.text(currentTank.getPower(), healthBarX + 60, healthBarY + 40); 
    
        parent.fill(oldFill);
        parent.stroke(oldStroke);
    }


    /**
     * Draws the scoreboard including the scores of all players and the wind value.
     */
    public void drawScoreboard() {
        // Load the appropriate wind icon based on wind speed
        PImage windIcon;
        if (wind < 0) {
            windIcon = parent.loadImage("build/resources/main/Tanks/wind-1.png");
        } else {
            windIcon = parent.loadImage("build/resources/main/Tanks/wind.png");
        }
        windIcon.resize(0, 40); 
        parent.image(windIcon, scoreboardX+30, scoreboardY-40); 
        parent.textSize(20); 
        parent.text(String.valueOf(Math.abs(wind)), scoreboardX + 80, scoreboardY-12); // Draw the wind speed
    
        // Calculate the height of the scoreboard based on the number of tanks
        int playerHeight = 20; 
        scoreboardHeight = 60 + allTanks.size() * playerHeight; 
        scoreboardY = 45; 
    
        // Draw the scoreboard rectangle
        parent.noFill(); 
        parent.stroke(0); 
        parent.rect(scoreboardX, scoreboardY, scoreboardWidth+15, scoreboardHeight);
    
        // Draw the "Scores" title
        parent.fill(0);
        parent.textSize(20); 
        parent.text("Scores", scoreboardX + 10, scoreboardY + 30); 
    
        // Draw the help box
        int helpBoxX = scoreboardX + 120; 
        int helpBoxY = scoreboardY - 40; 
        int helpBoxWidth = 50; 
        int helpBoxHeight = 28; 
        parent.fill(255); 
        parent.rect(helpBoxX-5, helpBoxY, helpBoxWidth, helpBoxHeight+5);
        parent.fill(0); 
        parent.textSize(17); 
        parent.text("HELP", 5+helpBoxX + helpBoxWidth / 2 - 30, helpBoxY + helpBoxHeight / 2 + 9);
    
        // Draw the separating line
        parent.line(scoreboardX, scoreboardY + 40, scoreboardX + scoreboardWidth+15, scoreboardY + 40);
    
        // Draw the scores of all players
        parent.textSize(15); 
        Tank[] tanksArray = new Tank[allTanks.size()];
        for (Tank tank : allTanks) {
            tanksArray[tank.gettankindex()] = tank;
        }
        // Draw the scores of all players based on how they appear in the txt file
        for (int i = 0; i < tanksArray.length; i++) {
            Tank tank = tanksArray[i];
            String[] rgb = tank.getColor().split(",");
            int red = Integer.parseInt(rgb[0]);
            int green = Integer.parseInt(rgb[1]);
            int blue = Integer.parseInt(rgb[2]);
            parent.fill(red, green, blue); 
            String player = "Player " + (char)('A' + i);
            String score = "Score: " + tank.getScore();
            parent.text(player + ": " + score, scoreboardX + 10, scoreboardY + 60 + i * playerHeight);
        }
    }

    /**
     * Draws the help box to see all the shortcuts and power-ups available in the game.
     */
    public void drawHelperScreen() {
        isHelpBoxOpen = true;
        int rectangleWidth = 400; 
        int rectangleHeight = 300; 
    
        parent.fill(255); 
        parent.rect(parent.width / 2 - rectangleWidth / 2, parent.height / 2 - rectangleHeight / 2, rectangleWidth, rectangleHeight);
    
        parent.fill(0); 
        int xPosition = parent.width / 2 + rectangleWidth / 2 - 40; 
        int yPosition = parent.height / 2 - rectangleHeight / 2 + 10; 
        parent.line(xPosition, yPosition, xPosition + 20, yPosition + 20); 
        parent.line(xPosition, yPosition + 20, xPosition + 20, yPosition); 
        
        // Draw the keys and their roles
        parent.textSize(15); // Set the text size
        parent.text("Up: Move turret right", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 40);
        parent.text("Down: Move turret left", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 60);
        parent.text("Right: Move tank right", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 80);
        parent.text("Left: Move tank left", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 100);
        parent.text("W: Increase turret power", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 120);
        parent.text("S: Decrease turret power", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 140);
        parent.text("Space: To fire the projectile", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 160);

    
        // Draw the power-ups and their costs
        parent.text("Buy Power-ups:", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 200);
        parent.text("r: Repair tank (+20 in health for 20 score points)", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 220);
        parent.text("f: Fuel tank (+200 for 10 score points)", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 240);
        parent.text("p: Buy extra parachute (+1 for 15 score points)", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 260);
        parent.text("r: Reset game when game is over !!", parent.width / 2 - rectangleWidth / 2 + 10, parent.height / 2 - rectangleHeight / 2 + 280);
    }
    

    /**
     * Handles the mouse events to close the help box when the user clicks on the close button.
     * @param e The mouse event.
     */
    public void mouseEvent(MouseEvent e) {
        if (e.getAction() == MouseEvent.PRESS) {
            int rectangleWidth = 400; 
            int rectangleHeight = 300; 
            int xPosition = parent.width / 2 + rectangleWidth / 2 - 40; 
            int yPosition = parent.height / 2 - rectangleHeight / 2 + 10; 
    
            
            if (e.getX() >= xPosition && e.getX() <= xPosition + 20 &&
                e.getY() >= yPosition && e.getY() <= yPosition + 20) {
                // Close the help box
                isHelpBoxOpen = false;
                app.helperscreen = false;
            }
        }
    }
    
}