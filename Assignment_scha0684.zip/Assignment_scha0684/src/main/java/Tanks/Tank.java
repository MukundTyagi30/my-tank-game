/*
 * This class handle the tank objects and its atributes in the game.
 * It also handles the projectile firing and updating the projectile position.
 * It take care for the animating and handeling the explosion of the projectile.
 */

package Tanks;
import processing.core.PApplet;
import processing.core.PImage;


public class Tank {
    private String color;
    private int power;
    public int health;
    public int score;
    public int fuel;
    public int parachutes;
    private int xtank;
    private int ytank;
    private float angle;
    private PApplet p;
    private float projectilestartX = 0;
    private float projectilestartY = 0;
    private int nozzleLength = -20;
    private boolean tankfired;
    public int TANK_WIDTH = 26;
    public int TANK_HEIGHT = 8;
    public int nozzleStartX;
    public int nozzleStartY;
    public int nozzleEndX = nozzleStartX;
    public int nozzleEndY = nozzleStartY - 10;
    public float projectileX;
    public float projectileY;
    public float projectileVx;
    public float projectileVy;
    public int explosionCounter;
    public Boolean isparachuteopen = false;
    public int tankindex = 0;
    public float turretx;
    public float turrety;
    public int mKeyCounter = 0;
    public int rKeyCounter = 0;
    public int fKeyCounter = 0;
    public int pKeyCounter = 0;
    public long turnStartTime = 0;
    private boolean falling; 
    private int initialY; 




    public Tank(PApplet p, String color, int xtank, int ytank) {
        this.color = color;
        this.power = 50;
        this.health = 100;
        this.score = 0;
        this.fuel = 250;
        this.parachutes = 3;
        this.xtank = xtank;
        this.ytank = ytank;
        this.angle = 0;
        this.tankfired = false;
        this.p = p;
    }

    // getters and setters for all necessary attributes
    public String getColor() {
        return color;
    }

    public int getExplosionCounter() {
        return explosionCounter;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setexplosionCounter(int counter) {
        this.explosionCounter = counter;
    }

    public void getexplosionCounter() {
        this.explosionCounter = explosionCounter;
    }


    public boolean isFalling() {
        return falling;
    }

    public void setFalling(boolean falling) {
        this.falling = falling;
    }

    public int getInitialY() {
        return initialY;
    }

    public void setInitialY(int initialY) {
        this.initialY = initialY;
    }


    public void settankindex(int tankindex) {
        this.tankindex = tankindex;
    }

    public void decrementKeyCounters() {
        if (rKeyCounter > 0) rKeyCounter--;
        if (fKeyCounter > 0) fKeyCounter--;
        if (pKeyCounter > 0) pKeyCounter--;
    }

    public int gettankindex() {
        return tankindex;
    }

    public float getProjectileX() {
        return projectileX;
    }

    public void setProjectileX(int projectileX) {
        this.projectileX = projectileX;
    }

    public float getProjectileY() {
        return projectileY;
    }

    public void setProjectileY(int projectileY) {
        this.projectileY = projectileY;
    }

    public float getturretx() {
        return turretx;
    }   

    public float getturrety() {
        return turrety;
    }

    
    public void setturretx(float turretx) {
        this.turretx = turretx;
    }

    public void setturrety(float turrety) {
        this.turrety = turrety;
    }

    public int getPower() {
        return power;
    }

    public boolean isTankfired() {
        return tankfired;
    }

    public void setTankfired(boolean tankfired) {
        this.tankfired = tankfired;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public Tank(PApplet p) {
        this.p = p;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getFuel() {
        return fuel;
    }

    public void setFuel(int fuel) {
        this.fuel = fuel;
    }

    public int getParachutes() {
        return parachutes;
    }

    public void setParachutes(int parachutes) {
        this.parachutes = parachutes;
    }

    public int getXtank() {
        return xtank;
    }

    public void setXtank(int xtank) {
        this.xtank = xtank;
    }

    public int getYtank() {
        return ytank;
    }

    public void setYtank(int ytank) {
        this.ytank = ytank;
    }

    public float getAngle() {
        return angle;
    }

    public void setAngle(float angle) {
        this.angle = angle;
    }

    public float projectilestartX() {
        return projectilestartX;
    }

    public void setprojectilestartX(float projectilestartx) {
        this.projectilestartX = projectilestartx;
    }

    public float projectilestartY() {
        return projectilestartY;
    }

    public void setprojectilestartY(float projectilestarty) {
        this.projectilestartY = projectilestarty;
    }


    /**
     * This method is used to draw the explosion animation on the screen.
     * @param p: PApplet object
     * @param x: x-coordinate of the explosion
     * @param y: y-coordinate of the explosion
     */
    public void printExplosion(PApplet p, float x, float y) {
        p.noStroke();
        // Draw the outermost (red) ring if explosionCounter is 2 or more
        if (explosionCounter >= 4) {
            p.fill(255, 0, 0);
            p.ellipse(x, y, 60, 60); 
        }
    
        // Draw the middle (orange) ring if explosionCounter is 1 or more
        if (explosionCounter >= 2) {
            p.fill(255, 165, 0);
            p.ellipse(x, y, 40, 40);
        }
    
        // Draw the innermost (white) ring if explosionCounter is 0 or more
        if (explosionCounter >= 0) {
            p.fill(255, 255, 255); 
            p.ellipse(x, y, 20, 20); 
        }
    }
        

    /**
     * Handles the firing of the projectile and calculating its progression based on power and turrets angle.
     * @param p: PApplet object
     * @param angle: angle of the turret
     * @param startX: x-coordinate of the projectile
     * @param startY: y-coordinate of the projectile
     * @param power: power of the projectile
     */
    public void fireProjectile(PApplet p, float angle, float startX, float startY, int power) {
        // Split the color string into RGB components
        String[] rgb = this.color.split(",");
        int red = Integer.parseInt(rgb[0]);
        int green = Integer.parseInt(rgb[1]);
        int blue = Integer.parseInt(rgb[2]);
    
        p.fill(red, green, blue); 
        angle = p.radians(angle); // Convert angle to radians
        float initialVelocity = 1 + (-power / 100.0f) * 10; // Velocity ranges from 1 to 9 based on power
        float vx = (float) (-initialVelocity * Math.sin(angle));
        float vy = (float) (initialVelocity * Math.cos(angle)); // Negative sign added to account for the upward direction    
        // Store initial position and velocity
        projectileX = startX;
        projectileY = startY;
        projectileVx = vx;
        projectileVy = vy;
    }
    

    /**
     * This method is responsible for updating the projectile's position based on its velocity and acceleration.
     * @param p: PApplet object
     * @param wind: wind force
     */
    public void updateProjectile(PApplet p, int wind) {
        // Update projectile position
        if (projectileY < p.height) { // Assuming height is the screen height
            projectileVx += wind / 1000.0f; // Apply wind force
            projectileX += projectileVx; // Update x position
            projectileY += projectileVy; // Update y position
    
            // Apply gravity
            projectileVy += 3.6f / 60; 

            // to make the projectile of the same colour as the tank
            String[] rgb = this.color.split(",");
            int red = Integer.parseInt(rgb[0]);
            int green = Integer.parseInt(rgb[1]);
            int blue = Integer.parseInt(rgb[2]);
            p.fill(red, green, blue); 
            p.ellipse(projectileX, projectileY, 10, 10); 
        }
    }

    
    /**
     * In this method we just draw the tanks on the screen.
     * @param p: PApplet object
     * @param xcoor: x-coordinate of the tank
     * @param ycoor: y-coordinate of the tank
     * @param colour: colour of the tank
     * @param angle: angle of the turret
     */
    public void drawTank(PApplet p, int xcoor, int ycoor, String colour, float angle) {
        // Load the parachute image
        PImage parachute = p.loadImage("build/resources/main/Tanks/parachute.png");
    
        // Split the colour string into RGB components
        String[] rgb = colour.split(",");
        int red = Integer.parseInt(rgb[0]);
        int green = Integer.parseInt(rgb[1]);
        int blue = Integer.parseInt(rgb[2]);

        int x = xcoor-15;
        int y = ycoor;
    
        p.fill(red, green, blue); 
        p.noStroke(); 
        p.rect(x, y, TANK_WIDTH, TANK_HEIGHT);
        p.rect(x + TANK_WIDTH/4, y - TANK_HEIGHT/2, TANK_WIDTH/2, TANK_HEIGHT/2);
        p.stroke(0); 
        p.strokeWeight(2); 
        nozzleStartX = x + TANK_WIDTH/2;
        nozzleStartY = y - TANK_HEIGHT/2; 
        p.pushMatrix(); // Save the current transformation matrix
        p.translate(nozzleStartX, nozzleStartY); 
        p.rotate(p.radians(angle)); 
        p.line(0, 0, 0, nozzleLength); 
        float turretX = nozzleStartX;
        float turretY = nozzleStartY;
        this.turretx = turretX;
        this.turrety = turretY;        
        p.popMatrix(); 
        if(this.isparachuteopen){
            // Draw the parachute image above the tank, centered horizontally
            p.image(parachute, x + TANK_WIDTH/2 - parachute.width/2, y - parachute.height);
            isparachuteopen = false;
        }


    }

}