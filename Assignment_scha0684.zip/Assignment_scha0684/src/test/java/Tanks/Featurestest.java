/*
 * This file contains tests for the Features class.
 */

package Tanks;


import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import processing.event.MouseEvent;

import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import processing.core.PImage;



public class Featurestest {


    // Test the constructor
    @Test
    public void testConstructor() {
        App app = new App();
        PApplet pApplet = new Apptesting();
        Tank tank1 = new Tank(pApplet, "255,0,0", 100, 100);
        List<Tank> tanks = new ArrayList<>();
        tanks.add(tank1);
        Features features = new Features(pApplet, tanks, tank1, app);

        assertEquals(pApplet, features.parent);
        assertEquals(tanks, features.tanks);
        assertEquals(tank1, features.currentTank);
        assertEquals(app, features.app);
    }


    // Testing if the logic for setting the wind speed is correct
    @Test
    public void testSetWind() {
        App app = new App();
        PApplet pApplet = new Apptesting();
        Tank tank1 = new Tank(pApplet, "255,0,0", 100, 100);
        List<Tank> tanks = new ArrayList<>();
        tanks.add(tank1);
        Features features = new Features(pApplet, tanks, tank1, app);

        features.setWind(10);
        assertEquals(10, features.wind);
    }


    // Test the draw method for the helper option screen 
    @Test
    public void testDrawHelperScreen() {
    // Mock the PApplet class
    PApplet mockPApplet = mock(PApplet.class);
    App mockApp = mock(App.class);
    mockPApplet.width = 800;
    mockPApplet.height = 600;
    List<Tank> tanks = new ArrayList<>();

    Features features = new Features(mockPApplet, tanks, null, mockApp);


    // Call the method to test
    features.drawHelperScreen();

    // Verify that the fill, rect, line, and text methods of the mocked PApplet class were called with the correct arguments
    InOrder inOrder = inOrder(mockPApplet);

    // Check the fill and rect calls for the help box
    inOrder.verify(mockPApplet).fill(255);
    inOrder.verify(mockPApplet).rect(200, 150, 400, 300);

    // Check the fill and line calls for the close button
    inOrder.verify(mockPApplet).fill(0);
    inOrder.verify(mockPApplet).line(560, 160, 580, 180);
    inOrder.verify(mockPApplet).line(560, 180, 580, 160);
    // Check the text calls for the instructions
    inOrder.verify(mockPApplet).textSize(15);
    inOrder.verify(mockPApplet).text("Up: Move turret right", 210, 190);
    inOrder.verify(mockPApplet).text("Down: Move turret left", 210, 210);
// Repeat for each call to text() in your drawHelperScreen() method

    // Check the text calls for the instructions
    inOrder.verify(mockPApplet).textSize(15);
    inOrder.verify(mockPApplet).text(anyString(), anyFloat(), anyFloat());
    // Repeat the above line for each text call in your method

    // Check that the help box is open
    assertTrue(features.isHelpBoxOpen, "The help box should be open after calling drawHelperScreen()");
}


// Test the draw method for the when drawing the score board for the players
@Test
public void testDrawScoreboard() {
    // Mock the PApplet, App and Tank classes
    PApplet mockPApplet = mock(PApplet.class);
    App mockApp = mock(App.class);
    Tank mockTank = mock(Tank.class);

    // Stub out the methods that are called on the mockPApplet
    when(mockPApplet.loadImage(anyString())).thenReturn(mock(PImage.class));
    doNothing().when(mockPApplet).image(any(PImage.class), anyFloat(), anyFloat());
    doNothing().when(mockPApplet).textSize(anyInt());
    doNothing().when(mockPApplet).text(anyString(), anyFloat(), anyFloat());
    doNothing().when(mockPApplet).noFill();
    doNothing().when(mockPApplet).stroke(anyInt());
    doNothing().when(mockPApplet).rect(anyFloat(), anyFloat(), anyFloat(), anyFloat());
    doNothing().when(mockPApplet).fill(anyInt(), anyInt(), anyInt());
    doNothing().when(mockPApplet).line(anyFloat(), anyFloat(), anyFloat(), anyFloat());
    when(mockTank.getColor()).thenReturn("255,0,0");
    when(mockTank.getScore()).thenReturn(0);
    List<Tank> tanks = new ArrayList<>();
    tanks.add(mockTank); 
    Tank mockTank2 = mock(Tank.class);
    when(mockTank2.getColor()).thenReturn("0,255,0");
    when(mockTank2.getScore()).thenReturn(1);
    tanks.add(mockTank2);

    Tank mockTank3 = mock(Tank.class);
    when(mockTank3.getColor()).thenReturn("0,0,255");
    when(mockTank3.getScore()).thenReturn(2);
    tanks.add(mockTank3);

    Features features = new Features(mockPApplet, tanks, null, mockApp);

    // Call the method to test
    features.drawScoreboard();

    // Verify that the fill and text methods were called with the correct arguments
    verify(mockPApplet).fill(255, 0, 0);
    verify(mockPApplet).text("Player A: Score: 0", anyFloat(), anyFloat());
    verify(mockPApplet).fill(0, 255, 0);
    verify(mockPApplet).text("Player B: Score: 1", anyFloat(), anyFloat());
    verify(mockPApplet).fill(0, 0, 255);
    verify(mockPApplet).text("Player C: Score: 2", anyFloat(), anyFloat());
}


    // Test drawScoreboard when wind speed is less than 0
    @Test
    public void testDrawScoreboard_WindLessThanZero() {
        // Arrange
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Features features = new Features(mockPApplet, new ArrayList<>(), null, mockApp);
        features.wind = -1;

        // Stub out the methods that are called on the mockPApplet
        when(mockPApplet.loadImage(anyString())).thenReturn(mock(PImage.class));
        doNothing().when(mockPApplet).image(any(PImage.class), anyFloat(), anyFloat());

        // Act
        features.drawScoreboard();

        // Assert
        verify(mockPApplet).loadImage("src/main/resources/Tanks/wind.png");
    }

    // Test drawScoreboard when wind speed is 0 or greater
    @Test
    public void testDrawScoreboard_WindZeroOrGreater() {
        // Arrange
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Features features = new Features(mockPApplet, new ArrayList<>(), null, mockApp);
        features.wind = 0;

        // Stub out the methods that are called on the mockPApplet
        when(mockPApplet.loadImage(anyString())).thenReturn(mock(PImage.class));
        doNothing().when(mockPApplet).image(any(PImage.class), anyFloat(), anyFloat());

        // Act
        features.drawScoreboard();

        // Assert
        verify(mockPApplet).loadImage("src/main/resources/Tanks/wind.png");
    }

    // Test drawScoreboard with multiple tanks
    @Test
    public void testDrawScoreboard_MultipleTanks() {
        // Arrange
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Tank mockTank = mock(Tank.class);
        when(mockTank.getColor()).thenReturn("255,0,0");
        when(mockTank.getScore()).thenReturn(0);
        when(mockTank.gettankindex()).thenReturn(0);
        List<Tank> tanks = new ArrayList<>();
        tanks.add(mockTank); 
        Tank mockTank2 = mock(Tank.class);
        when(mockTank2.getColor()).thenReturn("0,255,0");
        when(mockTank2.getScore()).thenReturn(1);
        when(mockTank2.gettankindex()).thenReturn(1);
        tanks.add(mockTank2);
        Features features = new Features(mockPApplet, tanks, null, mockApp);

        // Stub out the methods that are called on the mockPApplet
        when(mockPApplet.loadImage(anyString())).thenReturn(mock(PImage.class));
        doNothing().when(mockPApplet).image(any(PImage.class), anyFloat(), anyFloat());

        // Act
        features.drawScoreboard();

        // Assert
        verify(mockPApplet).fill(255, 0, 0);
        verify(mockPApplet).text("Player A: Score: 0", anyFloat(), anyFloat());
        verify(mockPApplet).fill(0, 255, 0);
        verify(mockPApplet).text("Player B: Score: 1", anyFloat(), anyFloat());
    }


    // testing the draw method for the current player
    @Test
    public void testDrawCurrentPlayer() {
        // Mock the PApplet, App and Tank classes
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Tank mockTank = mock(Tank.class);
    
        // Stub out the methods that are called on the mockPApplet
        when(mockPApplet.loadImage(anyString())).thenReturn(mock(PImage.class));
        doNothing().when(mockPApplet).image(any(PImage.class), anyFloat(), anyFloat());
        doNothing().when(mockPApplet).textSize(anyInt());
        doNothing().when(mockPApplet).text(anyString(), anyFloat(), anyFloat());
        doNothing().when(mockPApplet).noFill();
        doNothing().when(mockPApplet).stroke(anyInt());
        doNothing().when(mockPApplet).rect(anyFloat(), anyFloat(), anyFloat(), anyFloat());
        doNothing().when(mockPApplet).fill(anyInt(), anyInt(), anyInt());
        doNothing().when(mockPApplet).line(anyFloat(), anyFloat(), anyFloat(), anyFloat());
        doNothing().when(mockPApplet).text(anyString(), anyFloat(), anyFloat());
    
        // Set up the mock Tanks
        when(mockTank.getColor()).thenReturn("255,0,0");
        when(mockTank.getFuel()).thenReturn(10);
        when(mockTank.getHealth()).thenReturn(50);
        when(mockTank.getPower()).thenReturn(30);
        when(mockTank.getParachutes()).thenReturn(5);
        List<Tank> tanks = new ArrayList<>();
        tanks.add(mockTank); // Add the mock tank to the list
    
        Features features = new Features(mockPApplet, tanks, null, mockApp);
    
        // Set the parent and currentTank fields
        features.parent = mockPApplet;
        features.currentTank = mockTank;
        features.drawCurrentPlayer(features.currentTank);

        // Verify that the fill, textSize, text, image, noFill, rect, stroke, and line methods were called with the correct arguments
        verify(mockPApplet, times(3)).fill(anyInt());
        verify(mockPApplet, times(3)).textSize(anyInt());
        verify(mockPApplet, times(6)).text(anyString(), anyFloat(), anyFloat());
        verify(mockPApplet, times(2)).image(any(PImage.class), anyFloat(), anyFloat());
        verify(mockPApplet).noFill();
        verify(mockPApplet, times(2)).rect(anyFloat(), anyFloat(), anyFloat(), anyFloat());
        verify(mockPApplet).stroke(anyInt(), anyInt(), anyInt());
        verify(mockPApplet).line(anyFloat(), anyFloat(), anyFloat(), anyFloat());
    }


    // Test the conditions when mouseEvent is called
    @Test
    public void testMouseEvent() {
        // Arrange
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Features features = new Features(mockPApplet, new ArrayList<>(), null, mockApp);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getAction()).thenReturn(MouseEvent.PRESS);
        // Set the mouse position to be within the specified area
        int rectangleWidth = 400;
        int rectangleHeight = 300;
        int xPosition = mockPApplet.width / 2 + rectangleWidth / 2 - 40;
        int yPosition = mockPApplet.height / 2 - rectangleHeight / 2 + 10;
        when(mockEvent.getX()).thenReturn(xPosition + 10);
        when(mockEvent.getY()).thenReturn(yPosition + 10);

        // Act
        features.mouseEvent(mockEvent);

        // Assert
        assertFalse(features.isHelpBoxOpen);
        assertFalse(mockApp.helperscreen);
    }


    // Test mouseEvent when the event is not a press
    @Test
    public void testMouseEvent_NotPress() {
        // Arrange
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Features features = new Features(mockPApplet, new ArrayList<>(), null, mockApp);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getAction()).thenReturn(MouseEvent.RELEASE);

        // Act
        features.mouseEvent(mockEvent);

        // Assert
        assertTrue(features.isHelpBoxOpen);
        assertTrue(mockApp.helperscreen);
    }

    // Test mouseEvent when the event is a press but the mouse position is not within the specified area
    @Test
    public void testMouseEvent_PressOutsideArea() {
        // Arrange
        PApplet mockPApplet = mock(PApplet.class);
        App mockApp = mock(App.class);
        Features features = new Features(mockPApplet, new ArrayList<>(), null, mockApp);

        MouseEvent mockEvent = mock(MouseEvent.class);
        when(mockEvent.getAction()).thenReturn(MouseEvent.PRESS);
        // Set the mouse position to be outside the specified area
        when(mockEvent.getX()).thenReturn(0);
        when(mockEvent.getY()).thenReturn(0);

        // Act
        features.mouseEvent(mockEvent);

        // Assert
        assertTrue(features.isHelpBoxOpen);
        assertTrue(mockApp.helperscreen);
    }


}