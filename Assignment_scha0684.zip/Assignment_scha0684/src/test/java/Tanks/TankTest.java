/*
 * This file contains the testcases for tank.java file
 
 */

package Tanks;

import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import processing.core.PApplet;
import processing.core.PImage;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class TankTest {

    // Here we testing all getter and setter methods in the file
    @Test
    public void testTankMethods() {
        PApplet p = new PApplet();
        Tank tank = new Tank(p);

        // Test setColor and getColor
        tank.setColor("red");
        assertEquals("red", tank.getColor());

        // Test settankindex and gettankindex
        tank.settankindex(1);
        assertEquals(1, tank.gettankindex());

        // Test setturretx and getturretx
        tank.setturretx(10.0f);
        assertEquals(10.0f, tank.getturretx());

        // Test setturrety and getturrety
        tank.setturrety(20.0f);
        assertEquals(20.0f, tank.getturrety());

        // Test setPower and getPower
        tank.setPower(30);
        assertEquals(30, tank.getPower());

        // Test setTankfired and isTankfired
        tank.setTankfired(true);
        assertTrue(tank.isTankfired());

        // Test setHealth and getHealth
        tank.setHealth(40);
        assertEquals(40, tank.getHealth());

        // Test setScore and getScore
        tank.setScore(50);
        assertEquals(50, tank.getScore());

        // Test setFuel and getFuel
        tank.setFuel(60);
        assertEquals(60, tank.getFuel());

        // Test setParachutes and getParachutes
        tank.setParachutes(70);
        assertEquals(70, tank.getParachutes());

        // Test setXtank and getXtank
        tank.setXtank(80);
        assertEquals(80, tank.getXtank());

        // Test setYtank and getYtank
        tank.setYtank(90);
        assertEquals(90, tank.getYtank());

        // Test setAngle and getAngle
        tank.setAngle(100.0f);
        assertEquals(100.0f, tank.getAngle());

        // Test setprojectilestartX and projectilestartX
        tank.setprojectilestartX(110.0f);
        assertEquals(110.0f, tank.projectilestartX());

        // Test setprojectilestartY and projectilestartY
        tank.setprojectilestartY(120.0f);
        assertEquals(120.0f, tank.projectilestartY());
    }


    // Testing the game logic for the firing of the projectile 
    @Test
    public void testFireProjectile() {
        // Mock the PApplet class
        PApplet mockPApplet = mock(PApplet.class);
    
        Tank tank = new Tank(mockPApplet);
    
        // Set the color of the tank
        tank.setColor("255,0,0"); // Red color
    
        // Call the method to test
        tank.fireProjectile(mockPApplet, 45.0f, 100.0f, 200.0f, 50);
    
        // Check the state of the tank after firing the projectile
        assertEquals(100.0f, tank.getProjectileX(), "The initial X position of the projectile should be set correctly");
        assertEquals(200.0f, tank.getProjectileY(), "The initial Y position of the projectile should be set correctly");
        assertTrue(tank.projectileVx < 0, "The initial X velocity of the projectile should be negative");
        assertTrue(tank.projectileVy > 0, "The initial Y velocity of the projectile should be positive");
    
        // Verify that the fill method of the mocked PApplet class was called with the correct arguments
        verify(mockPApplet, times(1)).fill(255, 0, 0);
    }


    // Testing the game logic for when updating the coordinates of the projectile
    @Test
    public void testUpdateProjectile() {
        // Create a spy of the PApplet class
        PApplet spyPApplet = spy(PApplet.class);

        // Stub the height field
        int height = 300;
        Tank tank = new Tank(spyPApplet);
        tank.setColor("255,0,0");

        // Set the initial state of the projectile
        tank.setprojectilestartX(100.0f);
        tank.setprojectilestartY(200.0f);
        tank.projectileVx = (1.0f);
        tank.projectileVy = (-1.0f);

        // Call the method to test
        tank.updateProjectile(spyPApplet, 10);

        // Check the state of the tank after updating the projectile
        assertTrue(tank.projectileX > 100.0f, "The X position of the projectile should increase");
        assertTrue(tank.projectileY > 200.0f, "The Y position of the projectile should increase");
        assertTrue(tank.projectileVx > 1.0f, "The X velocity of the projectile should increase due to wind");
        assertTrue(tank.projectileVy > -1.0f, "The Y velocity of the projectile should increase due to gravity");

        // Verify that the methods of the mocked PApplet class were called with the correct arguments
        verify(spyPApplet, times(1)).fill(255, 0, 0);
        verify(spyPApplet, times(1)).ellipse(anyFloat(), anyFloat(), anyFloat(), anyFloat());
    }


    // Testing the getter method to get the x coordinates of the projectile
    @Test
    public void testGetProjectileX() {
        PApplet p = new PApplet();
        Tank tank = new Tank(p);
        tank.setprojectilestartX(100.0f);

        assertEquals(100.0f, tank.getProjectileX());
    }

    // Testing the getter method to get the y coordinates of the projectile
    @Test
    public void testGetProjectileY() {
        PApplet p = new PApplet();
        Tank tank = new Tank(p);

        tank.setprojectilestartY(200.0f);

        assertEquals(200.0f, tank.getProjectileY());
    }


    // Testing the drawtank() method
    @Test
    public void testDrawTank() {
        // Mock the PApplet class
        PApplet mockPApplet = mock(PApplet.class);

        // Mock the PImage class
        PImage mockPImage = mock(PImage.class);

        // When loadImage is called on the mock PApplet, return the mock PImage
        when(mockPApplet.loadImage(anyString())).thenReturn(mockPImage);

        // Create a Tank object
        Tank tank = new Tank(mockPApplet);

        // Call the method to test
        tank.drawTank(mockPApplet, 100, 200, "255,0,0", 45.0f);

        // Verify that the methods of the mocked PApplet class were called with the correct arguments
        verify(mockPApplet, times(1)).loadImage(anyString());
        verify(mockPApplet, times(1)).fill(255, 0, 0);
        verify(mockPApplet, times(1)).noStroke();
        verify(mockPApplet, times(2)).rect(anyInt(), anyInt(), anyInt(), anyInt());
        verify(mockPApplet, times(1)).stroke(0);
        verify(mockPApplet, times(1)).strokeWeight(2);
        verify(mockPApplet, times(1)).pushMatrix();
        verify(mockPApplet, times(1)).translate(anyFloat(), anyFloat());
        verify(mockPApplet, times(1)).rotate(anyFloat());
        verify(mockPApplet, times(1)).line(anyFloat(), anyFloat(), anyFloat(), anyFloat());
        verify(mockPApplet, times(1)).popMatrix();
    }


        // Test drawTank when isparachuteopen is true
    @Test
    public void testDrawTank_WithParachuteOpen() {
        // Mock the PApplet class
        PApplet mockPApplet = mock(PApplet.class);

        // Mock the PImage class
        PImage mockPImage = mock(PImage.class);

        // When loadImage is called on the mock PApplet, return the mock PImage
        when(mockPApplet.loadImage(anyString())).thenReturn(mockPImage);

        // Create a Tank object
        Tank tank = new Tank(mockPApplet);
        tank.isparachuteopen = true; // Set isparachuteopen to true

        // Call the method to test
        tank.drawTank(mockPApplet, 100, 200, "255,0,0", 45.0f);

        // Verify that the methods of the mocked PApplet class were called with the correct arguments
        verify(mockPApplet, times(2)).loadImage(anyString()); // loadImage is called twice: once for the tank and once for the parachute
        verify(mockPApplet, times(1)).fill(255, 0, 0);
        verify(mockPApplet, times(1)).noStroke();
        verify(mockPApplet, times(2)).rect(anyInt(), anyInt(), anyInt(), anyInt());
        verify(mockPApplet, times(1)).stroke(0);
        verify(mockPApplet, times(1)).strokeWeight(2);
        verify(mockPApplet, times(1)).pushMatrix();
        verify(mockPApplet, times(1)).translate(anyFloat(), anyFloat());
        verify(mockPApplet, times(1)).rotate(anyFloat());
        verify(mockPApplet, times(1)).line(anyFloat(), anyFloat(), anyFloat(), anyFloat());
        verify(mockPApplet, times(1)).popMatrix();
        verify(mockPApplet, times(1)).image(any(PImage.class), anyFloat(), anyFloat()); // image is called once for the parachute
    }

    // Test when explosionCounter is 0 or more
    @Test
    public void testPrintExplosion_ExplosionCounterZeroOrMore() {
        // Mock the PApplet class
        PApplet mockPApplet = mock(PApplet.class);

        Tank tank = new Tank(mockPApplet);
        tank.setexplosionCounter(0); // Set explosionCounter to 0

        // Call the method to test
        tank.printExplosion(mockPApplet, 100.0f, 200.0f);

        // Verify that the fill and ellipse methods of the mocked PApplet class were called with the correct arguments
        verify(mockPApplet).fill(255, 255, 255);
        verify(mockPApplet).ellipse(100.0f, 200.0f, 20, 20);
    }

    // Test when explosionCounter is 2 or more
    @Test
    public void testPrintExplosion_ExplosionCounterTwoOrMore() {
        // Mock the PApplet class
        PApplet mockPApplet = mock(PApplet.class);

        Tank tank = new Tank(mockPApplet);
        tank.setexplosionCounter(2); // Set explosionCounter to 2

        // Call the method to test
        tank.printExplosion(mockPApplet, 100.0f, 200.0f);

        // Verify that the fill and ellipse methods of the mocked PApplet class were called with the correct arguments
        InOrder inOrder = inOrder(mockPApplet);

        // Check middle (orange) ring
        inOrder.verify(mockPApplet).fill(255, 165, 0);
        inOrder.verify(mockPApplet).ellipse(100.0f, 200.0f, 40, 40);

        // Check innermost (white) ring
        inOrder.verify(mockPApplet).fill(255, 255, 255);
        inOrder.verify(mockPApplet).ellipse(100.0f, 200.0f, 20, 20);
    }

    // Test when explosionCounter is 4 or more
    @Test
    public void testPrintExplosion_ExplosionCounterFourOrMore() {
        // Mock the PApplet class
        PApplet mockPApplet = mock(PApplet.class);

        Tank tank = new Tank(mockPApplet);
        tank.setexplosionCounter(4); // Set explosionCounter to 4

        // Call the method to test
        tank.printExplosion(mockPApplet, 100.0f, 200.0f);

        // Verify that the fill and ellipse methods of the mocked PApplet class were called with the correct arguments
        InOrder inOrder = inOrder(mockPApplet);

        // Check outermost (red) ring
        inOrder.verify(mockPApplet).fill(255, 0, 0);
        inOrder.verify(mockPApplet).ellipse(100.0f, 200.0f, 60, 60);

        // Check middle (orange) ring
        inOrder.verify(mockPApplet).fill(255, 165, 0);
        inOrder.verify(mockPApplet).ellipse(100.0f, 200.0f, 40, 40);

        // Check innermost (white) ring
        inOrder.verify(mockPApplet).fill(255, 255, 255);
        inOrder.verify(mockPApplet).ellipse(100.0f, 200.0f, 20, 20);
    }

    // Test decrementKeyCounters when all counters are greater than 0
    @Test
    public void testDecrementKeyCounters_AllCountersGreaterThanZero() {
        // Create a Tank object
        Tank tank = new Tank(null);
        tank.rKeyCounter = 5;
        tank.fKeyCounter = 3;
        tank.pKeyCounter = 1;

        // Call the method to test
        tank.decrementKeyCounters();

        // Check that all counters have been decremented by 1
        assertEquals(4, tank.rKeyCounter, "The rKeyCounter should be decremented by 1");
        assertEquals(2, tank.fKeyCounter, "The fKeyCounter should be decremented by 1");
        assertEquals(0, tank.pKeyCounter, "The pKeyCounter should be decremented by 1");
    }

    // Test decrementKeyCounters when all counters are 0
    @Test
    public void testDecrementKeyCounters_AllCountersZero() {
        // Create a Tank object
        Tank tank = new Tank(null);
        tank.rKeyCounter = 0;
        tank.fKeyCounter = 0;
        tank.pKeyCounter = 0;

        // Call the method to test
        tank.decrementKeyCounters();

        // Check that all counters are still 0
        assertEquals(0, tank.rKeyCounter, "The rKeyCounter should remain 0");
        assertEquals(0, tank.fKeyCounter, "The fKeyCounter should remain 0");
        assertEquals(0, tank.pKeyCounter, "The pKeyCounter should remain 0");
    }

}