/*
 * This file is for testing the Loading class
 */

package Tanks;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import processing.core.PApplet;
import processing.core.PImage;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


public class loadingtest {

    @Mock
    PApplet parent;

    @Mock
    PImage image;

    @Test
    public void testDraw() {
        // Arrange
        MockitoAnnotations.openMocks(this);
        when(parent.loadImage(anyString())).thenReturn(image);
        Loading loading = new Loading(parent);
        
        // Act
        loading.draw();
        
        // Assert
        verify(parent, times(1)).image(image, 0, 0, 0, 0);
        verify(parent, times(2)).fill(anyFloat(), anyFloat(), anyFloat(), anyFloat());
        verify(parent, times(2)).textSize(32);
        verify(parent, times(2)).text(anyString(), anyFloat(), anyFloat());
    }

    // Test mouseClicked() method
    @Test
    public void testMouseClicked() {
        // Arrange
        PApplet parent = mock(PApplet.class);
        parent.width = 800;
        parent.height = 600;
        PImage image = mock(PImage.class);
        when(parent.loadImage(anyString())).thenReturn(image);
        Loading loading = new Loading(parent); // Create a new instance for this test
        
        // Act
        parent.mouseX = 400;
        parent.mouseY = 400;
        boolean result = loading.mouseClicked();
        
        // Assert
        assertTrue(result);
    }
    


    @Test
    public void testMouseClicked_SystemExit() {
        // Arrange
        PApplet parent = mock(PApplet.class);
        parent.width = 800;
        parent.height = 600;
        PImage image = mock(PImage.class);
        when(parent.loadImage(anyString())).thenReturn(image);
        Loading loading = new Loading(parent); // Create a new instance for this test
    
        try {
            // Act
            parent.mouseX = 400;
            parent.mouseY = 500; // Adjust this value to make the condition true
    
            // Assert
            assertThrows(SecurityException.class, loading::mouseClicked);
        } finally {
            // Reset the SecurityManager to the default (null)
            System.setSecurityManager(null);
        }
    }
    
        @Test
        public void testMouseClicked_OutsideButtons() {
            // Arrange
            PApplet parent = mock(PApplet.class);
            parent.width = 800;
            parent.height = 600;
            PImage image = mock(PImage.class);
            when(parent.loadImage(anyString())).thenReturn(image);
            Loading loading = new Loading(parent); // Create a new instance for this test

            // Act
            parent.mouseX = 0; // Set mouseX and mouseY to values that are outside both buttons' areas
            parent.mouseY = 0;
            boolean result = loading.mouseClicked();

            // Assert
            assertFalse(result); // Assert that mouseClicked() returns false
        }

    // Test when UP key is pressed
        @Test
        public void testKeyPressed_UpKey() {
            // Arrange
            PApplet parent = mock(PApplet.class);
            Loading loading = new Loading(parent);

            // Act
            parent.keyCode = PApplet.UP;
            boolean result = loading.keyPressed();

            // Assert
            assertFalse(result);
        }

    // Test when DOWN key is pressed
    @Test
    public void testKeyPressed_DownKey() {
        // Arrange
        PApplet parent = mock(PApplet.class);
        Loading loading = new Loading(parent);

        // Act
        parent.keyCode = PApplet.DOWN;
        boolean result = loading.keyPressed();

        // Assert
        assertFalse(result);
    }

    // Test when ENTER key is pressed and selectedButton is 0
    @Test
    public void testKeyPressed_EnterKey_SelectedButton0() {
        // Arrange
        PApplet parent = mock(PApplet.class);
        Loading loading = new Loading(parent);
        loading.selectedButton = 0;

        // Act
        parent.keyCode = PApplet.ENTER;
        boolean result = loading.keyPressed();

        // Assert
        assertTrue(result);
    }

    // Test when ENTER key is pressed and selectedButton is 1
    @Test
    public void testKeyPressed_EnterKey_SelectedButton1() {
        // Arrange
        PApplet parent = mock(PApplet.class);
        Loading loading = new Loading(parent);
        loading.selectedButton = 1;

        // Act
        parent.keyCode = PApplet.ENTER;

        // Assert
        assertThrows(SecurityException.class, loading::keyPressed);
    }

    // Test when any other key is pressed
    @Test
    public void testKeyPressed_OtherKey() {
        // Arrange
        PApplet parent = mock(PApplet.class);
        Loading loading = new Loading(parent);

        // Act
        parent.keyCode = PApplet.BACKSPACE; // Any key other than UP, DOWN, ENTER, or RETURN
        boolean result = loading.keyPressed();

        // Assert
        assertFalse(result);
    }

}