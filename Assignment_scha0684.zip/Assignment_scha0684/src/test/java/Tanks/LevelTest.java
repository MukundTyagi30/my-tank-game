/*
 * This file contains the testcases for level.java file
 */


package Tanks;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import java.util.Map;
import java.util.HashMap;


public class LevelTest {

    // Testing if the getcurrentlevelfile method returns the correct level file
    @Test
    public void testGetCurrentLevelFile() {
        App app = new App();
        Level level = new Level(app);

        // Check that the current level file is correct
        assertEquals("level1.txt", level.getCurrentLevelFile());
    }

    // Testing if the progress level() working properly as intended
    @Test
    public void testProgressLevel() {
        App app = new App();
        Level level = new Level(app);

        // Progress to the next level
        level.progressLevel();

        // Check that the current level has increased
        assertEquals("level2.txt", level.getCurrentLevelFile());
    }


    // Testing the storeScores() method
    @Test
    public void testStoreScores() {
        App app = new App();
        Level level = new Level(app);

        // Add a tank to the app
        Tank tank = new Tank(app);
        tank.setScore(100);
        tank.settankindex(0);
        tank.setColor("255,0,0");
        app.tanks.add(tank);

        // Store the scores
        level.storeScores();

        // Check that the scores were stored correctly
        int[] expectedScoreAndIndex = {100, 0};
        assertArrayEquals(expectedScoreAndIndex, level.getColorScores().get("255,0,0"));
    }


    // Testing the getAndSetColorScores() method
    @Test
    public void testGetAndSetColorScores() {
        App app = new App();
        Level level = new Level(app);

        // Set the color scores
        Map<String, int[]> colorScores = new HashMap<>();
        colorScores.put("255,0,0", new int[]{100, 0});
        level.setColorScores(colorScores);

        // Check that getColorScores returns the correct value
        assertArrayEquals(new int[]{100, 0}, level.getColorScores().get("255,0,0"));
    }

    // testing if the final leader board is being printed properly or not 
    @Test
    public void testDrawLeaderboard() {
        // Mock the App class
        App mockApp = mock(App.class);
    
        Level level = new Level(mockApp);
    
        // Set the color scores
        Map<String, int[]> colorScores = new HashMap<>();
        colorScores.put("255,0,0", new int[]{100, 0});
        colorScores.put("0,255,0", new int[]{200, 1});
        colorScores.put("0,0,255", new int[]{300, 2});
        level.setColorScores(colorScores);
    
        // Manually set the leaderboardIndex to a value greater than 0
        level.leaderboardIndex = 1;
    
        // Call the method to test
        level.drawLeaderboard();
    
        // Verify that the methods of the mocked App class were called with the correct arguments
        verify(mockApp, times(1)).fill(255, 200, 200);
        verify(mockApp, times(1)).stroke(0);
        verify(mockApp, times(1)).rect(anyInt(), anyInt(), anyInt(), anyInt());
        verify(mockApp, times(1)).textSize(32);
        verify(mockApp, times(1)).fill(255);
        verify(mockApp, times(1)).text(eq("Leaderboard:"), anyInt(), anyInt());
        verify(mockApp, times(1)).line(anyInt(), anyInt(), anyInt(), anyInt());
    
        // Verify that the fill and text methods were called with the correct arguments for the first entry
        verify(mockApp, times(1)).fill(255, 0, 0);
        verify(mockApp, times(1)).text(eq("Player A: 100 points"), anyInt(), anyInt());
    }

}