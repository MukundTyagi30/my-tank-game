/*
 * This file contains testcases for the app.java file
 */


package Tanks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;
import processing.core.PImage;
import processing.core.PApplet;
import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;
import java.util.stream.IntStream;
import java.util.stream.Collectors;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;
import processing.event.MouseEvent;
import processing.core.PGraphics;
import java.lang.reflect.Field;




public class Apptesting extends PApplet {
    @Override
    public void fill(float gray) {
        // Do nothing
    }

    @Override
    public void ellipse(float a, float b, float c, float d) {
        // Do nothing
    }
}

class TestApp extends App {
    @Override
    public PImage drawTerrain() {
        return new PImage(1, 1);
    }


    // Test the collision update function in the app.java
    @Test
    public void testCollisionUpdate() {
        TestApp app = new TestApp();

        List<int[]> heightsList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            int[] heights = new int[32];
            for (int j = 0; j < 32; j++) {
                heights[j] = 100;
            }
            heightsList.add(heights);
        }

        app.collisionUpdate(150, 150, heightsList);
        assertTrue(heightsList.get(4)[18] > 100);
        assertTrue(heightsList.get(5)[18] > 100);
        assertTrue(heightsList.get(4)[19] > 100);
        assertTrue(heightsList.get(5)[19] > 100);
    }

    //  Tests the checklevelover method in the App class.
    //This test verifies that the method correctly identifies whether there is only one tank left in the game.
    @Test
    public void testCheckLevelOver() throws NoSuchFieldException, IllegalAccessException {
        // Arrange
        App app = new App();
        Tank mockTank = mock(Tank.class);
    
        // Use reflection to set the tanks field
        Field field = App.class.getDeclaredField("tanks");
        field.setAccessible(true);
    
        // Act & Assert
        // Case when there is only one tank
        field.set(app, Collections.singletonList(mockTank));
        assertTrue(app.checklevelover());
    
        // Case when there are more than one tank
        Tank mockTank2 = mock(Tank.class);
        field.set(app, Arrays.asList(mockTank, mockTank2));
        assertFalse(app.checklevelover());
    }

    // this test is to check if the drawBackgroundAndTerrain() is properly called or not
    @Test
    public void testDrawBackgroundAndTerrain() throws Exception {
        // Arrange
        App app = Mockito.spy(new App());
        String currentFile = "currentFile";
        app.drawBackgroundAndTerrain();
        Mockito.verify(app).drawbackground(currentFile);
}



    // test drawtanks() function in the App class
    @Test
    public void testDrawTanks() throws Exception {
        // Arrange
        App app = new App();
        Tank mockTank1 = mock(Tank.class);
        Tank mockTank2 = mock(Tank.class);
        List<Tank> tanks = Arrays.asList(mockTank1, mockTank2);
    
        // Use reflection to set the tanks field
        Field field = App.class.getDeclaredField("tanks");
        field.setAccessible(true);
        field.set(app, tanks);
    
        // Act
        app.drawTanks();
    
        // Assert
        verify(mockTank1, times(1)).drawTank(any(App.class), anyInt(), anyInt(), any(), anyFloat());
        verify(mockTank2, times(1)).drawTank(any(App.class), anyInt(), anyInt(), any(), anyFloat());
        }



    // This test verifies the mousePressed method in the TestApp class.
    // It simulates a mouse click event within a specific rectangle on the screen.
    // The test ensures that when the game is started and a mouse click occurs within this rectangle,
    @Test
    public void testMousePressed() {
        // Arrange
        TestApp app = new TestApp();
        MouseEvent mockEvent = mock(MouseEvent.class);
    
        // Set the mouse position to be within the specified rectangle
        int rectangleX = 784;
        int rectangleY = 10;
        int rectangleWidth = 50;
        int rectangleHeight = 28;
        when(mockEvent.getX()).thenReturn(rectangleX + 25);
        when(mockEvent.getY()).thenReturn(rectangleY + 14);
    
        // Set gameStarted to true
        app.gameStarted = true;
    
        // Act
        app.mousePressed(mockEvent);
    
        // Assert
        assertTrue(app.helperscreen);
    }


    // This test verifies that when the game is not started and a mouse click occurs,
    // the mouseClicked method of the loadingScreen is called and gameStarted is set to true.
    @Test
    public void testMousePressedGameNotStarted() {
        // Arrange
        TestApp app = new TestApp();
        MouseEvent mockEvent = mock(MouseEvent.class);
        Loading mockLoadingScreen = mock(Loading.class);

        // Set gameStarted to false
        app.gameStarted = false;

        // Set loadingScreen to the mock
        app.loadingScreen = mockLoadingScreen;

        // Set the mock to return true when mouseClicked is called
        when(mockLoadingScreen.mouseClicked()).thenReturn(true);

        // Act
        app.mousePressed(mockEvent);

        // Assert
        assertTrue(app.gameStarted);
    }



// testing if the function will work when game started is being presented as false 
    @Test
    public void testKeyboardControls_false() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = RIGHT;
        app.keyPressed = true;
        app.keyCode = RIGHT;
        app.gameStarted = false;
    
        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;
    
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);
    
        app.tanks.add(tank);
        app.keyboardcontrols(0);
    
        // Verify that the tank's position has changed
        Mockito.verify(tank).setXtank(Mockito.anyInt());
        Mockito.verify(tank).setYtank(Mockito.anyInt());
    }


    // This test verifies that when the RIGHT key is pressed, the tank's position changes.
    // It does this by mocking the necessary objects and setting the required conditions for the RIGHT key press.
    // After the keyboardcontrols method is called, it checks that the tank's position has been updated.

    @Test
    public void testKeyboardControls_RIGHT() {
    App app = Mockito.spy(new App());
    app.tankturnCounter = 0;
    app.isPlaying = true;
    app.keyCode = RIGHT;
    app.keyPressed = true;
    app.keyCode = RIGHT;
    app.gameStarted = true;

    // Create a mock LoadingScreen and set it to the loadingScreen field of app
    Loading loadingScreen = Mockito.mock(Loading.class);
    app.loadingScreen = loadingScreen;

    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.getPower()).thenReturn(10);
    Mockito.when(tank.isTankfired()).thenReturn(false);
    Mockito.when(tank.getHealth()).thenReturn(20);
    Mockito.when(tank.getFuel()).thenReturn(20);

    app.tanks.add(tank);
    app.keyboardcontrols(0);

    // Verify that the tank's position has changed
    Mockito.verify(tank).setXtank(Mockito.anyInt());
    Mockito.verify(tank).setYtank(Mockito.anyInt());
}

    @Test
    public void testKeyboardControls_LEFT() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = LEFT; // Change to LEFT
        app.keyPressed = true;
        app.gameStarted = true;

        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        Mockito.verify(tank).setXtank(Mockito.anyInt());
        Mockito.verify(tank).setYtank(Mockito.anyInt());
    }

    @Test
    public void testKeyboardControls_NoFuel() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = RIGHT;
        app.keyPressed = true;
        app.gameStarted = true;

        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(0); // Change to 0

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        Mockito.verify(tank, Mockito.never()).setXtank(Mockito.anyInt()); // Verify that setXtank was not called
        Mockito.verify(tank, Mockito.never()).setYtank(Mockito.anyInt()); // Verify that setYtank was not called
    }

    @Test
    public void testKeyboardControls_GameNotStarted() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = RIGHT;
        app.keyPressed = true;
        app.gameStarted = false; // Set gameStarted to false

        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        Mockito.verify(loadingScreen).keyPressed(); // Verify that keyPressed was called on loadingScreen
    }


    // This test verifies that when the 'w' key is pressed, the tank's power increases.
    // It does this by mocking the necessary objects and setting the required conditions for the 'w' key press.
    // After the keyboardcontrols method is called, it checks that the tank's power has been updated.
    @Test
    public void testKeyboardControls_increaseturret() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.key = 'w';
        app.keyPressed = true;
        app.keyCode = 'w';
        app.gameStarted = true;

        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        // Verify that the tank's power has increased
        Mockito.verify(tank).setPower(Mockito.anyInt());
    }

    // This test verifies that when the 's' key is pressed, the tank's power decreases.
    // It does this by mocking the necessary objects and setting the required conditions for the 's' key press.
    // After the keyboardcontrols method is called, it checks that the tank's power has been updated.
    @Test
    public void testKeyboardControls_decreaseturret() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.key = 's';
        app.keyPressed = true;
        app.keyCode = 's';
        app.gameStarted = true;

        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        // Verify that the tank's power has decreased
        Mockito.verify(tank).setPower(Mockito.anyInt());
    }

    // This test verifies that when the 'r' key is pressed, the tank's mKeyCounter increases.
    // It does this by mocking the necessary objects and setting the required conditions for the 'r' key press.
    // After the keyboardcontrols method is called, it checks that the tank's mKeyCounter has been updated.
    @Test
    public void testKeyboardControls_testr() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.key = 'r';
        app.keyPressed = true;
        app.keyCode = 'r';
        app.gameStarted = true;
        app.isgameover = false; // Set game over state to false

        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        tank.rKeyCounter = 0; // Set rKeyCounter to 0
        tank.score = 30; // Set score to a value greater than repairAmount
        tank.health = 80; // Set initial health value
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(tank.health);
        Mockito.when(tank.getFuel()).thenReturn(20);

        Level level = Mockito.mock(Level.class);
        level.currentLevel = 1; // Set current level to a non-zero value
        app.level = level;

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        // Verify that the tank's health has increased, score has decreased, and rKeyCounter is set to 50
        assertEquals(100, tank.health);
        assertEquals(10, tank.score);
        assertEquals(50, tank.rKeyCounter);
    }



    // This test verifies that when the 'f' key is pressed, the tank fires.
    // It does this by mocking the necessary objects and setting the required conditions for the 'f' key press.
    // After the keyboardcontrols method is called, it checks that the tank has fired.
    @Test
    public void testKeyboardControls_testf() {
        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.key = 'f';
        app.keyPressed = true;
        app.keyCode = 'f';
        app.gameStarted = true;

        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        tank.fKeyCounter = 0; // Set fKeyCounter to 0
        tank.score = 20; // Set score to a value greater than repairAmount
        tank.fuel = 100; // Set initial fuel value
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(tank.fuel);

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        // Verify that the tank's fuel has increased and score has decreased
        assertEquals(300, tank.fuel);
        assertEquals(10, tank.score);
    }

    @Test
    public void testKeyboardControls_testp() {
        // Create a spy of the App class
        App app = Mockito.spy(new App());

        // Set up the initial state of the app
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.key = 'p';
        app.keyPressed = true;
        app.keyCode = 'p';
        app.gameStarted = true;


        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        // Create a mock of the Tank class
        Tank tank = Mockito.mock(Tank.class);
        tank.pKeyCounter = 0; // Set pKeyCounter to 0
        tank.score = 20; // Set score to a value greater than repairAmount
        tank.parachutes = 0; // Set initial parachutes value

        // Set up the return values for the tank's methods
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);

        // Add the mock tank to the app's tanks list
        app.tanks.add(tank);

        // Call the method under test
        app.keyboardcontrols(0);

        // Verify that the tank's parachutes has increased, score has decreased, and pKeyCounter is set to 50
        assertEquals(1, tank.parachutes);
        assertEquals(5, tank.score);
        assertEquals(50, tank.pKeyCounter);
    }

    @Test
public void testKeyboardControls_testf_NotEnoughScore() {
    App app = Mockito.spy(new App());
    app.tankturnCounter = 0;
    app.isPlaying = true;
    app.key = 'f';
    app.keyPressed = true;
    app.keyCode = 'f';
    app.gameStarted = true;

    Loading loadingScreen = Mockito.mock(Loading.class);
    app.loadingScreen = loadingScreen;

    Tank tank = Mockito.mock(Tank.class);
    tank.fKeyCounter = 0; // Set fKeyCounter to 0
    tank.score = 5; // Set score to a value less than repairAmount
    tank.fuel = 100; // Set initial fuel value

    app.tanks.add(tank);
    app.keyboardcontrols(0);

    assertEquals(100, tank.fuel); // Verify that tank.fuel did not change
    assertEquals(5, tank.score); // Verify that tank.score did not change
}

@Test
public void testKeyboardControls_testp_pKeyCounterNotZero() {
    App app = Mockito.spy(new App());
    app.tankturnCounter = 0;
    app.isPlaying = true;
    app.key = 'p';
    app.keyPressed = true;
    app.keyCode = 'p';
    app.gameStarted = true;

    Loading loadingScreen = Mockito.mock(Loading.class);
    app.loadingScreen = loadingScreen;

    Tank tank = Mockito.mock(Tank.class);
    tank.pKeyCounter = 50; // Set pKeyCounter to 50
    tank.score = 20; // Set score to a value greater than repairAmount
    tank.parachutes = 0; // Set initial parachutes value

    app.tanks.add(tank);
    app.keyboardcontrols(0);

    assertEquals(0, tank.parachutes); // Verify that tank.parachutes did not change
    assertEquals(20, tank.score); // Verify that tank.score did not change
}

@Test
public void testKeyboardControls_testp_NotEnoughScore() {
    App app = Mockito.spy(new App());
    app.tankturnCounter = 0;
    app.isPlaying = true;
    app.key = 'p';
    app.keyPressed = true;
    app.keyCode = 'p';
    app.gameStarted = true;

    Loading loadingScreen = Mockito.mock(Loading.class);
    app.loadingScreen = loadingScreen;

    Tank tank = Mockito.mock(Tank.class);
    tank.pKeyCounter = 0; // Set pKeyCounter to 0
    tank.score = 10; // Set score to a value less than repairAmount
    tank.parachutes = 0; // Set initial parachutes value

    app.tanks.add(tank);
    app.keyboardcontrols(0);

    assertEquals(0, tank.parachutes); // Verify that tank.parachutes did not change
    assertEquals(10, tank.score); // Verify that tank.score did not change
}

    /**
     * This test case is designed to test the 'UP' key condition in the keyboardcontrols method.
     * The 'UP' key is supposed to increase the turret angle of the tank.
     * We set up a mock Tank and App, and simulate the 'UP' key being pressed.
     * We then call the keyboardcontrols method and verify that it was called correctly.
     */
    @Test
    public void testKeyboardControls_turretup() {
        // Create a spy of the App class
        App app = Mockito.spy(new App());

        // Set up the initial state of the app
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = UP;
        app.keyPressed = true;
        app.gameStarted = true;

        // Create a mock of the Tank class
        Tank tank = Mockito.mock(Tank.class);
        tank.mKeyCounter = 0;

        // Create a mock LoadingScreen and set it to the loadingScreen field of app
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        // Set up the return values for the tank's methods
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);
        Mockito.when(tank.getAngle()).thenReturn(85.0f); // Set initial angle to a value that will cause newAngle to exceed 90

        // Add the mock tank to the app's tanks list
        app.tanks.add(tank);

        // Call the method under test
        app.keyboardcontrols(0);

        // Verify that the method was called
        Mockito.verify(app).keyboardcontrols(0);

        // Verify that the tank's angle has been capped at 90
        Mockito.verify(tank).setAngle(90.0f);
    }

    /**
     * This test case is designed to test the 'DOWN' key condition in the keyboardcontrols method.
     * The 'DOWN' key is supposed to decrease the turret angle of the tank.
     * We set up a mock Tank and App, and simulate the 'DOWN' key being pressed.
     */
    @Test
    public void testKeyboardControls_turretdown() {
        // Create a spy of the App class
        App app = Mockito.spy(new App());

        // Set up the initial state of the app
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = DOWN;
        app.keyPressed = true;
        app.gameStarted = true;

        // Create a mock of the Tank class
        Tank tank = Mockito.mock(Tank.class);
        tank.mKeyCounter = 0;
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;


        // Set up the return values for the tank's methods
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);
        Mockito.when(tank.getAngle()).thenReturn(45.0f); // Set initial angle

        // Add the mock tank to the app's tanks list
        app.tanks.add(tank);

        // Call the method under test
        app.keyboardcontrols(0);

        // Verify that the method was called
        Mockito.verify(app).keyboardcontrols(0);

        // Verify that the tank's angle has decreased
        Mockito.verify(tank).setAngle(Mockito.floatThat(newAngle -> newAngle < 45.0f));
    }

    @Test
    public void testKeyboardControls_turretup_angleAtMax() {
        // This test case verifies that when the 'UP' key is pressed and the tank's angle is already at 90 degrees,
        // the angle does not increase further.

        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = UP;
        app.keyPressed = true;
        app.gameStarted = true;

        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getAngle()).thenReturn(90.0f); // Set initial angle to 90

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        // Verify that tank.setAngle() is called with 90.0f
        Mockito.verify(tank).setAngle(90.0f);
    }

    @Test
    public void testKeyboardControls_turretdown_angleAtMin() {
        // This test case verifies that when the 'DOWN' key is pressed and the tank's angle is already at -90 degrees,
        // the angle does not decrease further.

        App app = Mockito.spy(new App());
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.keyCode = DOWN;
        app.keyPressed = true;
        app.gameStarted = true;

        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;

        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getAngle()).thenReturn(-90.0f); // Set initial angle to -90

        app.tanks.add(tank);
        app.keyboardcontrols(0);

        // Verify that tank.setAngle() is called with -90.0f
        Mockito.verify(tank).setAngle(-90.0f);
    }

    /**
     * This test case is designed to test the 'SPACE' key condition in the keyboardcontrols method.
     * The 'SPACE' key is supposed to fire a projectile from the tank.
     * We set up a mock Tank and App, and simulate the 'SPACE' key being pressed.
     */
    @Test
    public void testKeyboardControls_shotprojectile() {
        // Create a spy of the App class
        App app = Mockito.spy(new App());

        // Set up the initial state of the app
        app.tankturnCounter = 0;
        app.isPlaying = true;
        app.key = ' ';
        app.keyPressed = true;
        app.gameStarted = true;

        // Create a mock of the Tank class
        Tank tank = Mockito.mock(Tank.class);
        tank.mKeyCounter = 0;
        Loading loadingScreen = Mockito.mock(Loading.class);
        app.loadingScreen = loadingScreen;


        // Set up the return values for the tank's methods
        Mockito.when(tank.getPower()).thenReturn(10);
        Mockito.when(tank.isTankfired()).thenReturn(false);
        Mockito.when(tank.getHealth()).thenReturn(20);
        Mockito.when(tank.getFuel()).thenReturn(20);

        // Add the mock tank to the app's tanks list
        app.tanks.add(tank);
        // Call the method under test
        app.keyboardcontrols(0);

        // Verify that the method was called
        Mockito.verify(app).keyboardcontrols(0);

        // Verify that the tank's isTankfired method returns true
        Mockito.verify(tank).isTankfired();
    }
    

    // test update wind function in the App class
    @Test
    public void testUpdateWind() {
        // Arrange
        TestApp app = new TestApp();
        app.wind = 0;

        // Act
        for (int i = 0; i < 1000; i++) { 
            app.updatewind();

            // Assert
            assertTrue(app.wind >= -35 && app.wind <= 35, "Wind should be within the range -35 to 35");
        }
}

    // test getterrainheightatx() function by giving sample values and checking against the expected values
    @Test
    public void testGetTerrainHeightAtX() {
        // Arrange
        App app = new App();
        List<int[]> heightsList = new ArrayList<>();
        heightsList.add(new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31});
        heightsList.add(new int[]{32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63});
        List<Integer> xValues = Arrays.asList(0, 32);

        // Act & Assert
        for (int x = 0; x < 64; x++) {
            int height = app.getTerrainHeightAtX(x, heightsList, xValues);
            assertEquals(x, height, "Height should be equal to x");
        }

        // Test for x value outside the range
        int height = app.getTerrainHeightAtX(64, heightsList, xValues);
        assertEquals(-1, height, "Height should be -1 for x outside the range");
    }


    // test initializetank() function in the App class
    @Test
    public void testInitializeTank() {
        // Arrange
        App app = new App();
        char[][] map = new char[20][28];
        for (int i = 0; i < 20; i++) {
            Arrays.fill(map[i], ' ');
        }
        map[10][14] = 'A';
        app.map = map;
        int CELLSIZE = 32;
        app.heightsList = Arrays.asList(new int[]{0, 0, 10, 0, 0});
        app.xValues = Arrays.asList(0, 10, 20, 30, 40);
        app.level = new Level(app);
        Map<String, int[]> colorScores = new HashMap<>();
        colorScores.put("0,0,255", new int[]{100, 1});
        app.level.setColorScores(colorScores);
    
        // Act
        app.initializeTank("config.txt");
    
        // Assert
        assertFalse(app.tanks.isEmpty(), "Tanks list should not be empty");
        if (!app.tanks.isEmpty()) {
            Tank tank = app.tanks.get(0);
            assertEquals("0,0,255", tank.getColor(), "Tank colour should be 0, 0, 255");
            assertEquals(462, tank.getXtank(), "Tank x-coordinate should be 462");
            assertEquals(-9, tank.getYtank(), "Tank y-coordinate should be -9");
            assertEquals(100, tank.getScore(), "Tank score should be 100");
            assertEquals(1, tank.gettankindex(), "Tank index should be 1");
    }
}


// testing the game logic for handle tank firing function 
@Test
public void testHandleTankFiring() {
    App app = new App();

    // Create a PApplet object with a height of 400
    Tank tank = Mockito.mock(Tank.class);
    
    Mockito.when(tank.isTankfired()).thenReturn(true);
    Mockito.when(tank.getProjectileX()).thenReturn((float)50);
    Mockito.when(tank.getProjectileY()).thenReturn((float)50);

    // Create a tank and set its properties
    tank.setTankfired(true);
    explosion = false;
    wind = 23;
    tankturnCounter = 0;
    tank.setprojectilestartX(50);
    tank.setprojectilestartY(50);
    tank.setHealth(100);
    tank.setPower(100);

    app.tanks.add(tank);

    app.heightsList = new ArrayList<>();
    for (int i = 0; i < 28; i++) {
        int[] row = new int[32];
        Arrays.fill(row, 350); 
        app.heightsList.add(row);
    }

    
    app.handleTankFiring(tank);
    Mockito.verify(tank).updateProjectile(Mockito.any(App.class), Mockito.anyInt());

}

// testing the game logic for handle tank firing function second branch 
@Test
public void testHandleTankFiring_firstif(){
    // Create a mock Tank object
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.isTankfired()).thenReturn(true);
    Mockito.when(tank.getProjectileX()).thenReturn((float)-1);
    Mockito.when(tank.getProjectileY()).thenReturn((float)10000.0); // Set Y position to be greater than terrain height
    Mockito.when(tank.getExplosionCounter()).thenReturn(2); // Mock the getter for explosionCounter
    Mockito.doNothing().when(tank).updateProjectile(Mockito.any(PApplet.class), Mockito.anyInt()); // Mock updateProjectile method
    Mockito.doNothing().when(tank).printExplosion(Mockito.any(PApplet.class), Mockito.anyFloat(), Mockito.anyFloat()); // Mock printExplosion method

    App app = new App();
    app.tanks = new ArrayList<>();
    app.tanks.add(tank);
    app.heightsList = new ArrayList<>();
    int[] row = new int[51];
    Arrays.fill(row, 350); 
    app.heightsList.add(row);
    app.heightsList.get(0)[50] = 40;

    app.handleTankFiring(tank);
}


// testing the game logic for handle tank firing function third if branch 

@Test
public void testHandleTankFiring_secondif(){
    // Create a mock Tank object
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.isTankfired()).thenReturn(true);
    Mockito.when(tank.getProjectileX()).thenReturn((float)10);
    Mockito.when(tank.getProjectileY()).thenReturn((float)10000.0); // Set Y position to be greater than terrain height
    Mockito.when(tank.getExplosionCounter()).thenReturn(2); // Mock the getter for explosionCounter
    Mockito.doNothing().when(tank).updateProjectile(Mockito.any(PApplet.class), Mockito.anyInt()); // Mock updateProjectile method
    Mockito.doNothing().when(tank).printExplosion(Mockito.any(PApplet.class), Mockito.anyFloat(), Mockito.anyFloat()); // Mock printExplosion method

    App app = new App();
    app.tanks = new ArrayList<>();
    app.tanks.add(tank);
    app.heightsList = new ArrayList<>();
    int[] row = new int[51];
    Arrays.fill(row, 350); 
    app.heightsList.add(row);
    app.heightsList.get(0)[50] = 40;

    app.handleTankFiring(tank);
}


// testing the game logic for handle tank firing function fourth if branch 

@Test
public void testHandleTankFiring_thirdif(){
    // Create a mock Tank object
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.isTankfired()).thenReturn(true);
    Mockito.when(tank.getProjectileX()).thenReturn((float)20);
    Mockito.when(tank.getProjectileY()).thenReturn((float)620.0); 
    Mockito.when(tank.getExplosionCounter()).thenReturn(2); 
    Mockito.doNothing().when(tank).updateProjectile(Mockito.any(PApplet.class), Mockito.anyInt()); 
    Mockito.doNothing().when(tank).printExplosion(Mockito.any(PApplet.class), Mockito.anyFloat(), Mockito.anyFloat()); 
    App app = Mockito.spy(new App());
    Mockito.doNothing().when(app).collisionUpdate(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyList());   

    app.tanks = new ArrayList<>();
    app.tanks.add(tank);
    app.heightsList = new ArrayList<>();
    int[] row = new int[51];
    Arrays.fill(row, 350); 
    app.heightsList.add(row);
    app.heightsList.get(0)[50] = 40;

    app.handleTankFiring(tank);
}

@Test
public void testHandleTankFiring_tankNotFired() {
    // This test case verifies that when the tank has not fired, the projectile does not update.

    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.isTankfired()).thenReturn(false); // Set tank not fired

    App app = new App();
    app.tanks = new ArrayList<>();
    app.tanks.add(tank);

    app.handleTankFiring(tank);

    // Verify that updateProjectile() is not called
    Mockito.verify(tank, Mockito.never()).updateProjectile(Mockito.any(App.class), Mockito.anyInt());
}

@Test
public void testHandleTankFiring_projectileInBounds() {
    // This test case verifies that when the projectile is not out of bounds, the projectile's position does not reset.

    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.isTankfired()).thenReturn(true);
    Mockito.when(tank.getProjectileX()).thenReturn((float)10);
    Mockito.when(tank.getProjectileY()).thenReturn((float)10); // Set Y position to be within terrain height

    App app = new App();
    app.tanks = new ArrayList<>();
    app.tanks.add(tank);

    app.handleTankFiring(tank);

    // Verify that setProjectileX() and setProjectileY() are not called
    Mockito.verify(tank, Mockito.never()).setProjectileX(Mockito.anyInt());
    Mockito.verify(tank, Mockito.never()).setProjectileY(Mockito.anyInt());
}

@Test
public void testHandleTankFiring_projectileNotHitTerrain() {
    // This test case verifies that when the projectile does not hit the terrain, the collision does not handle.

    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.isTankfired()).thenReturn(true);
    Mockito.when(tank.getProjectileX()).thenReturn((float)10);
    Mockito.when(tank.getProjectileY()).thenReturn((float)10); // Set Y position to be within terrain height

    App app = Mockito.spy(new App());
    app.tanks = new ArrayList<>();
    app.tanks.add(tank);

    app.handleTankFiring(tank);

    // Verify that handleProjectileTerrainCollision() is not called
    Mockito.verify(app, Mockito.never()).handleProjectileTerrainCollision(Mockito.any(Tank.class));
}


// This test verifies that the drawTurnIndicator method in the App class
// does not throw any exceptions when called with a valid Tank object.
@Test
public void testDrawTurnIndicator() {
    App app = new App();
    PApplet pApplet = new PApplet();
    Tank tank = new Tank(pApplet, "255,0,0", 100, 100);
    assertDoesNotThrow(() -> app.drawTurnIndicator(tank));
}


@Test
public void testCheckParachuteDeployment() {
    App app = new App();
    PApplet pApplet = new PApplet();
    Tank tank = new Tank(pApplet, "255,0,0", 100, 100);
    app.tanks.add(tank);
    app.heightsList = new ArrayList<int[]>(Collections.nCopies(200, new int[]{50})); 
    app.xValues = IntStream.range(0, 200).boxed().collect(Collectors.toList()); 
    app.checkParachuteDeployment();

    assertFalse(app.parachuteDeployed);
}

// Test case for when the tank's Y position is greater than 630 and it's the last tank in the list
@Test
public void testCheckParachuteDeployment_tankAboveGround() {
    App app = new App();
    Tank tank1 = mock(Tank.class);
    Tank tank2 = mock(Tank.class);

    when(tank1.getYtank()).thenReturn(600); // Y position is less than 630
    when(tank2.getYtank()).thenReturn(700); // Y position is greater than 630

    app.tanks.add(tank1);
    app.tanks.add(tank2);
    app.tankturnCounter = 1; // tank2 is the last tank in the list
    app.heightsList = new ArrayList<int[]>(Collections.nCopies(200, new int[]{50})); 
    app.xValues = IntStream.range(0, 200).boxed().collect(Collectors.toList()); 

    app.checkParachuteDeployment();

    assertFalse(app.tanks.contains(tank2)); // tank2 should be removed
    assertEquals(0, app.tankturnCounter); // tankturnCounter should be decremented
}

// Test case for when the tank's Y position is less than the terrain height at the tank's X position minus 8
@Test
public void testCheckParachuteDeployment_tankBelowTerrain() {
    App app = new App();
    Tank tank = mock(Tank.class);

    when(tank.getYtank()).thenReturn(40); // Y position is less than terrain height minus 8
    when(tank.getXtank()).thenReturn(100); // X position

    app.tanks.add(tank);
    app.heightsList = new ArrayList<int[]>(Collections.nCopies(200, new int[]{50})); 
    app.xValues = IntStream.range(0, 200).boxed().collect(Collectors.toList()); 

    app.checkParachuteDeployment();

    assertTrue(app.parachuteDeployed); // parachuteDeployed should be true
}

// Test case for when parachuteDeployed is false
@Test
public void testHandleParachuteDeployment_notDeployed() {
    App app = new App();
    app.parachuteDeployed = false;
    assertDoesNotThrow(() -> app.handleParachuteDeployment());
}

// Test case for when a tank is not on the ground
@Test
public void testHandleParachuteDeployment_tankNotOnGround() {
    App app = new App();
    app.parachuteDeployed = true;
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.getYtank()).thenReturn(650);
    app.impactedTanks.add(tank);
    app.handleParachuteDeployment();
    assertFalse(app.tanks.contains(tank));
}

// Test case for when a tank has a parachute and is still in the air
@Test
public void testHandleParachuteDeployment_tankWithParachute() {
    App app = new App();
    app.parachuteDeployed = true;
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.getYtank()).thenReturn(60);
    Mockito.when(tank.getParachutes()).thenReturn(1);
    app.impactedTanks.add(tank);
    app.handleParachuteDeployment();
    Mockito.verify(tank).setYtank(61);
}

// Test case for when a tank has no parachute and is still in the air
@Test
public void testHandleParachuteDeployment_tankWithoutParachute() {
    App app = new App();
    app.parachuteDeployed = true;
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.getYtank()).thenReturn(60);
    Mockito.when(tank.getParachutes()).thenReturn(0);
    app.impactedTanks.add(tank);
    app.handleParachuteDeployment();
    Mockito.verify(tank).setYtank(62);
}

// Test case for when a tank has landed on the ground
@Test
public void testHandleParachuteDeployment_tankOnGround() {
    App app = new App();
    app.parachuteDeployed = true;
    Tank tank = Mockito.mock(Tank.class);
    Mockito.when(tank.getYtank()).thenReturn(50);
    app.impactedTanks.add(tank);
    app.handleParachuteDeployment();
    assertFalse(app.impactedTanks.contains(tank));
}
        
    // Test case for when a tank has landed on the ground
    @Test
    public void testHandleParachuteDeployment_tankLanded() {
        App app = new App();
        app.parachuteDeployed = true;
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getYtank()).thenReturn(50);
        Mockito.when(app.getTerrainHeightAtX(anyInt(), anyList(), anyList())).thenReturn(50);
        app.impactedTanks.add(tank);
        app.handleParachuteDeployment();
        Mockito.verify(tank, Mockito.atLeastOnce()).getYtank();
    }

    // Test case for when all impacted tanks have been processed
    @Test
    public void testHandleParachuteDeployment_allTanksProcessed() {
        App app = new App();
        app.parachuteDeployed = true;
        Tank tank1 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getYtank()).thenReturn(50);
        app.impactedTanks.add(tank1);
        app.handleParachuteDeployment();
        Mockito.verify(tank1, Mockito.times(1)).getYtank();
    }

    // Test case for when parachuteDeployed is true but there are no impacted tanks
    @Test
    public void testHandleParachuteDeployment_noImpactedTanks() {
        App app = new App();
        app.parachuteDeployed = true;
        app.handleParachuteDeployment();
        assertFalse(app.parachuteDeployed);
    }

    @Test
    public void testHandleCollision() {
        App app = new App();
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getProjectileX()).thenReturn(50.0f);
        Mockito.when(tank.getProjectileY()).thenReturn(60.0f);
        app.handleCollision(tank);
        Mockito.verify(tank).setexplosionCounter(0);
    }

    @Test
    public void testHandleImpactedTanks() {
        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getProjectileX()).thenReturn(50.0f);
        Mockito.when(tank1.getProjectileY()).thenReturn(60.0f);
        Mockito.when(tank2.getXtank()).thenReturn(70);
        Mockito.when(tank2.getYtank()).thenReturn(80);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        app.tanks.add(tank2);
        app.handleImpactedTanks(tank1);
        Mockito.verify(tank2).setHealth(anyInt());
    }

    @Test
    public void testHandleImpactedTanks_noImpact() {
        // This test case verifies that when the distance between the tank's projectile and another tank is greater than 30,
        // the other tank's health does not change.

        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getProjectileX()).thenReturn(50.0f);
        Mockito.when(tank1.getProjectileY()).thenReturn(60.0f);
        Mockito.when(tank2.getXtank()).thenReturn(100); // Set X position to be more than 30 units away
        Mockito.when(tank2.getYtank()).thenReturn(100);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        app.tanks.add(tank2);
        app.handleImpactedTanks(tank1);

        // Verify that setHealth() is not called
        Mockito.verify(tank2, Mockito.never()).setHealth(anyInt());
    }


    @Test
    public void testHandleImpactedTanks_tankSurvives() {
        // This test case verifies that when the other tank's health after impact is greater than 0,
        // the other tank is not removed from the list.

        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getProjectileX()).thenReturn(50.0f);
        Mockito.when(tank1.getProjectileY()).thenReturn(60.0f);
        Mockito.when(tank2.getXtank()).thenReturn(50);
        Mockito.when(tank2.getYtank()).thenReturn(60);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        app.tanks.add(tank2);
        app.handleImpactedTanks(tank1);

        // Verify that the tank is still in the list
        assertTrue(app.tanks.contains(tank2));
    }


    @Test
    public void testCalculateDistance() {
        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getProjectileX()).thenReturn(50.0f);
        Mockito.when(tank1.getProjectileY()).thenReturn(60.0f);
        Mockito.when(tank2.getXtank()).thenReturn(70);
        Mockito.when(tank2.getYtank()).thenReturn(80);
        double distance = app.calculateDistance(tank1, tank2);
        assertTrue(distance > 0);
    }


    // test if we calculating and applying damage correctly or not 
    @Test
    public void testCalculateAndApplyDamage() {
        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getProjectileX()).thenReturn(50.0f);
        Mockito.when(tank1.getProjectileY()).thenReturn(60.0f);
        Mockito.when(tank2.getXtank()).thenReturn(70);
        Mockito.when(tank2.getYtank()).thenReturn(80);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        app.calculateAndApplyDamage(tank1, tank2, 10.0);
        Mockito.verify(tank2).setHealth(anyInt());
    }

    @Test
    public void testCalculateAndApplyDamage_negativeDamage() {
        // This test case verifies that when the calculated damage is less than 0, it is set to 0.

        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        app.calculateAndApplyDamage(tank1, tank2, 50.0); // Set distance to be more than 30

        // Verify that setHealth() is called with the original health
        Mockito.verify(tank2).setHealth(100);
    }

    @Test
    public void testCalculateAndApplyDamage_differentTanks() {
        // This test case verifies that when the other tank is not the same as the tank that fired the projectile,
        // the score of the tank that fired the projectile is increased.

        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank1.getScore()).thenReturn(0);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        app.calculateAndApplyDamage(tank1, tank2, 10.0); // Set distance to be less than 30

        // Verify that setScore() is called with a positive value
        Mockito.verify(tank1).setScore(anyInt());
    }

    @Test
    public void testCalculateAndApplyDamage_healthLessThanPower() {
        // This test case verifies that when the other tank's health is less than its power,
        // the power of the other tank is set to its health.

        App app = new App();
        Tank tank1 = Mockito.mock(Tank.class);
        Tank tank2 = Mockito.mock(Tank.class);
        Mockito.when(tank2.getHealth()).thenReturn(100);
        Mockito.when(tank2.getPower()).thenReturn(200);
        app.calculateAndApplyDamage(tank1, tank2, 10.0); // Set distance to be less than 30

        // Verify that setPower() is called with a value equal to the new health
        Mockito.verify(tank2).setPower(anyInt());
    }


    // testing the game logic for when tank is updated with parachute 
    @Test
    public void testHandleTankWithParachute() {
        App app = new App();
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getYtank()).thenReturn(60);
        Mockito.when(tank.getParachutes()).thenReturn(1);
        app.impactedTanks.add(tank);
        app.handleTankWithParachute(tank, 61, 0);
        Mockito.verify(tank).setYtank(61);
    }

    @Test
    public void testHandleTankWithoutParachute_notFalling() {
        // This test case verifies that when the tank is not falling, it starts falling and its initial Y position is set.

        App app = new App();
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.isFalling()).thenReturn(false);
        Mockito.when(tank.getYtank()).thenReturn(60);
        app.handleTankWithoutParachute(tank, 100, 0);

        // Verify that setInitialY() and setFalling() are called
        Mockito.verify(tank).setInitialY(60);
        Mockito.verify(tank).setFalling(true);
    }

    @Test
    public void testHandleTankWithoutParachute_healthZero() {
        // This test case verifies that when the tank's health after falling is less than or equal to 0,
        // the tank's health is set to 0 and it is removed from the list.

        App app = new App();
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.isFalling()).thenReturn(true);
        Mockito.when(tank.getYtank()).thenReturn(100);
        Mockito.when(tank.getInitialY()).thenReturn(0);
        Mockito.when(tank.getHealth()).thenReturn(100);
        app.tanks.add(tank);
        app.handleTankWithoutParachute(tank, 101, 0);

        // Verify that setHealth() is called with 0 and the tank is removed from the list
        Mockito.verify(tank).setHealth(0);
        assertFalse(app.tanks.contains(tank));
    }

    @Test
    public void testHandleTankWithoutParachute_healthLessThanPower() {
        // This test case verifies that when the tank's health after falling is greater than 0 but less than its power,
        // the power of the tank is set to its health.

        App app = new App();
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.isFalling()).thenReturn(true);
        Mockito.when(tank.getYtank()).thenReturn(100);
        Mockito.when(tank.getInitialY()).thenReturn(50);
        Mockito.when(tank.getHealth()).thenReturn(100);
        Mockito.when(tank.getPower()).thenReturn(200);
        app.tanks.add(tank);
        app.handleTankWithoutParachute(tank, 101, 0);

        // Verify that setPower() is called with a value equal to the new health
        Mockito.verify(tank).setPower(anyInt());
    }

    // testing the game logic for when tank is updated without parachute
    @Test
    public void testHandleTankWithoutParachute() {
        App app = new App();
        Tank tank = Mockito.mock(Tank.class);
        Mockito.when(tank.getYtank()).thenReturn(60);
        Mockito.when(tank.getParachutes()).thenReturn(0);
        app.impactedTanks.add(tank);
        app.handleTankWithoutParachute(tank, 62, 0);
        Mockito.verify(tank).setYtank(62);
    }


    // This test verifies the handleTankTurns method in the App class. It checks that if the tankturnCounter is greater than the number of tanks minus one, it gets reset to zero. 
    @Test
    public void testHandleTankTurns() {
        // Arrange
        App app = Mockito.spy(new App());
        PApplet pApplet = new PApplet();
        Tank tank1 = new Tank(pApplet, "255,0,0", 100, 100);
        Tank tank2 = new Tank(pApplet, "0,255,0", 200, 200);
        app.tanks.add(tank1);
        app.tanks.add(tank2);
        app.tankturnCounter = 2;
    
        // Mock the features object and the draw method
        Features featuresMock = Mockito.mock(Features.class);
        app.features = featuresMock;
        doNothing().when(featuresMock).draw(any(Tank.class));
    
        // Mock the keyboardcontrols and drawTurnIndicator methods
        doNothing().when(app).keyboardcontrols(anyInt());
        doNothing().when(app).drawTurnIndicator(any(Tank.class));
    
        // Act
        app.handleTankTurns();
    
        // Assert
        assertEquals(0, app.tankturnCounter, "Tank turn counter should be reset to 0");
        Mockito.verify(app).keyboardcontrols(0);
        Mockito.verify(featuresMock).draw(tank1);
        Mockito.verify(app).drawTurnIndicator(tank1);
    }

    @Test
    public void testHandleTankTurns_counterNotGreaterThanTanksSizeMinusOne() {
        // This test case verifies that when tankturnCounter is not greater than tanks.size() - 1,
        // the tankturnCounter does not reset to 0.

        // Arrange
        App app = Mockito.spy(new App());
        PApplet pApplet = new PApplet();
        Tank tank1 = new Tank(pApplet, "255,0,0", 100, 100);
        Tank tank2 = new Tank(pApplet, "0,255,0", 200, 200);
        app.tanks.add(tank1);
        app.tanks.add(tank2);
        app.tankturnCounter = 0; // Set tankturnCounter to 0

        // Mock the features object and the draw method
        Features featuresMock = Mockito.mock(Features.class);
        app.features = featuresMock;
        doNothing().when(featuresMock).draw(any(Tank.class));

        // Mock the keyboardcontrols and drawTurnIndicator methods
        doNothing().when(app).keyboardcontrols(anyInt());
        doNothing().when(app).drawTurnIndicator(any(Tank.class));

        // Act
        app.handleTankTurns();

        // Assert
        assertEquals(0, app.tankturnCounter, "Tank turn counter should remain 0");
        Mockito.verify(app).keyboardcontrols(0);
        Mockito.verify(featuresMock).draw(tank1);
        Mockito.verify(app).drawTurnIndicator(tank1);
    }


    // testing the smoothing function for calcualting terrian height
    @Test
    public void testCalculateHeights() {
        App app = new App();
        int[] y1 = new int[32];
        int[] y2 = new int[32];
        for (int i = 0; i < 32; i++) {
            y1[i] = i + 1;
            y2[i] = i + 33;
        }
    
        int[] heights = app.calculateHeights(y1, y2);
    
        // Expected heights are a rolling average of the next 32 elements from y1 and y2
        int[] expectedHeights = new int[32];
        for (int i = 0; i < 32; i++) {
            int sum = 0;
            int count = 0;
            for (int j = i; j < y1.length && count < 32; j++) {
                sum += y1[j];
                count++;
            }
            for (int j = 0; count < 32; j++) {
                sum += y2[j];
                count++;
            }
            expectedHeights[i] = sum / 32;
        }
    
        assertArrayEquals(expectedHeights, heights, "Heights should be correctly calculated");
    }
    

    // testing main game logic for initializing terrain 
    @Test
    public void testInitializeTerrainmain() {
        App app = spy(new App());
    
        // Create a map with the key "foreground-colour"
        Map<String, String> settings = new HashMap<>();
        settings.put("foreground-colour", "255,255,255");
    
        // Stub the methods that initializeTerrain calls internally
        when(app.drawMap(anyString())).thenReturn(new char[20][28]); 
        when(app.getConfigSettings(anyString())).thenReturn(settings);
        when(app.loadImage(anyString())).thenReturn(null);
        doNothing().when(app).initializeTank(anyString());
    
        // Call the method to test
        String currentfile = "level1.txt";
        app.initializeterrain(currentfile);
    
        // Verify that the stubbed methods were called with the expected arguments
        verify(app).drawMap(eq(currentfile));
        verify(app).getConfigSettings(eq(currentfile));
        verify(app, times(2)).loadImage(anyString());
        verify(app).initializeTank(eq(currentfile));
    }


    // testing if game correctly initialize the terrain when map contains x
    @Test
public void testInitializeTerrainWithX() {
    App app = spy(new App());

    // Create a map with the key "foreground-colour"
    Map<String, String> settings = new HashMap<>();
    settings.put("foreground-colour", "255,255,255");

    // Create a map that contains 'X'
    char[][] map = new char[][] {
        {' ', ' ', 'X'},
        {' ', ' ', ' '},
        {' ', ' ', ' '}
    };

    // Stub the methods that initializeTerrain calls internally
    when(app.drawMap(anyString())).thenReturn(map); 
    when(app.getConfigSettings(anyString())).thenReturn(settings);
    when(app.loadImage(anyString())).thenReturn(null);
    doNothing().when(app).initializeTank(anyString());

    // Call the method to test
    String currentfile = "level1.txt";
    app.initializeterrain(currentfile);

    // Verify that the stubbed methods were called with the expected arguments
    verify(app).drawMap(eq(currentfile));
    verify(app).getConfigSettings(eq(currentfile));
    verify(app, times(2)).loadImage(anyString());
    verify(app).initializeTank(eq(currentfile));
}


// testing if game correctly initialize the terrain when map contains T
@Test
public void testInitializeTerrainWithT() {
    App app = spy(new App());

    // Create a map with the key "foreground-colour"
    Map<String, String> settings = new HashMap<>();
    settings.put("foreground-colour", "255,255,255");

    // Create a map that contains 'T'
    char[][] map = new char[][] {
        {' ', ' ', 'T'},
        {' ', ' ', ' '},
        {' ', ' ', ' '}
    };

    // Stub the methods that initializeTerrain calls internally
    when(app.drawMap(anyString())).thenReturn(map); 
    when(app.getConfigSettings(anyString())).thenReturn(settings);
    when(app.loadImage(anyString())).thenReturn(null);
    doNothing().when(app).initializeTank(anyString());

    // Call the method to test
    String currentfile = "level1.txt";
    app.initializeterrain(currentfile);

    // Verify that the stubbed methods were called with the expected arguments
    verify(app).drawMap(eq(currentfile));
    verify(app).getConfigSettings(eq(currentfile));
    verify(app, times(2)).loadImage(anyString());
    verify(app).initializeTank(eq(currentfile));
}

// testing if game correctly initialize the terrain when map contains two X
@Test
public void testInitializeTerrainWithTwoX() {
    App app = spy(new App());

    // Create a map with the key "foreground-colour"
    Map<String, String> settings = new HashMap<>();
    settings.put("foreground-colour", "255,255,255");

    // Create a map that contains two 'X'
    char[][] map = new char[][] {
        {' ', 'X', ' '},
        {' ', ' ', ' '},
        {'X', ' ', ' '}
    };

    // Stub the methods that initializeTerrain calls internally
    when(app.drawMap(anyString())).thenReturn(map); 
    when(app.getConfigSettings(anyString())).thenReturn(settings);
    when(app.loadImage(anyString())).thenReturn(null);
    doNothing().when(app).initializeTank(anyString());

    // Call the method to test
    String currentfile = "level1.txt";
    app.initializeterrain(currentfile);

    // Verify that the stubbed methods were called with the expected arguments
    verify(app).drawMap(eq(currentfile));
    verify(app).getConfigSettings(eq(currentfile));
    verify(app, times(2)).loadImage(anyString());
    verify(app).initializeTank(eq(currentfile));
}
 



// This test case verifies that the getConfigSettings method correctly reads a configuration file and returns a map of settings for a given layout.\
// The test case creates a mock App object and calls the getConfigSettings method with a layout filename. The expected settings are then compared with the actual settings returned by the method.
@Test
public void testGetConfigSettings() {
    App app = new App();
    String layoutFilename = "level1.txt";

    Map<String, String> settings = app.getConfigSettings(layoutFilename);

    // Create expected settings
    Map<String, String> expectedSettings = new HashMap<>();
    expectedSettings.put("background", "snow.png"); 
    expectedSettings.put("foreground-colour", "255,255,255"); 
    expectedSettings.put("trees", "tree2.png"); 

    // Add expected player colours
    for (int i = 0; i <= 9; i++) {
        expectedSettings.put("player_colour_" + i, "0,0,0");
    }
    for (char c = 'A'; c <= 'D'; c++) {
        expectedSettings.put("player_colour_" + c, c == 'A' ? "0,0,255" : c == 'B' ? "255,0,0" : c == 'C' ? "0,255,255" : "255,255,0");
    }
    for (char c = 'E'; c <= 'I'; c++) {
        expectedSettings.put("player_colour_" + c, c == 'E' ? "0,255,0" : "random");
    }

    // Check if the settings are correct
    for (Map.Entry<String, String> entry : expectedSettings.entrySet()) {
        assertEquals(entry.getValue(), settings.get(entry.getKey()), "Settings should be correctly retrieved for " + entry.getKey());
    }
}


    @Test
    public void testDrawTerrain() {
        // Create a map with the key "foreground-colour"
        Map<String, String> settings = new HashMap<>();
        settings.put("foreground-colour", "255,255,255");
    
        // Create a map that contains 'X'
        char[][] map = new char[][] {
            {' ', ' ', 'X'},
            {' ', ' ', ' '},
            {' ', ' ', ' '}
        };
    
        // Mock PGraphics
        PGraphics mockPGraphics = mock(PGraphics.class);
    
        // Create a spy of App and override createGraphics
        App app = spy(new App() {
            @Override
            public PGraphics createGraphics(int width, int height) {
                return mockPGraphics;
            }
        });
    
        // Stub the methods that drawTerrain calls internally
        when(app.drawMap(anyString())).thenReturn(map); 
        when(app.getConfigSettings(anyString())).thenReturn(settings);
        when(app.loadImage(anyString())).thenReturn(null);
        doNothing().when(app).initializeTank(anyString());
    
        // Call the method to test
        String currentfile = "level1.txt";
        app.initializeterrain(currentfile);
    
        // Call drawTerrain
        PImage terrain = app.drawTerrain();
    
        // Verify that the terrain is not null
        assertNotNull(terrain);
    
        // Verify that the stubbed methods were called with the expected arguments
        verify(app).drawMap(eq(currentfile));
        verify(app).getConfigSettings(eq(currentfile));
        verify(app, times(2)).loadImage(anyString());
        verify(app).initializeTank(eq(currentfile));
    }

// DRAW STUFFF FR SO TIRED DOING THIS SH :(
    @Test
    public void testDraw() {
        // Create a spy of App
        App app = spy(new App());

        // Create mocks of the fields within App
        Level level = mock(Level.class);
        Loading loadingScreen = mock(Loading.class);
        Features features = mock(Features.class);

        // Set the fields within App to the mocks
        app.level = level;
        app.loadingScreen = loadingScreen;
        app.features = features;

        // Now you can stub the methods on the mocks
        doNothing().when(app).handleTankTurns();
        doNothing().when(app).checkParachuteDeployment();
        doNothing().when(app).handleParachuteDeployment();
        doNothing().when(app).handleTankFiring(any(Tank.class));
        doNothing().when(level).storeScores();
        doNothing().when(level).drawLeaderboard();
        doNothing().when(loadingScreen).draw();
        doNothing().when(features).drawHelperScreen();
        doNothing().when(level).progressLevel();
        doNothing().when(app).keyboardcontrols(anyInt());
        when(app.checklevelover()).thenReturn(false);


        app.isgameover = true;
        app.draw();
        verify(level).storeScores();
        verify(level).drawLeaderboard();
        verify(app).handleTankTurns();
        
        // Test when gameStarted is false
        app.isgameover = false;
        app.gameStarted = false;
        app.draw();
        verify(loadingScreen).draw();
        verify(app).keyboardcontrols(anyInt());
        
        // Test when helperscreen is true
        app.gameStarted = true;
        app.helperscreen = true;
        app.draw();
        verify(features).drawHelperScreen();
        
        // Test when checklevelover is true
        app.helperscreen = false;
        when(app.checklevelover()).thenReturn(true);
        app.draw();
        verify(level).progressLevel();
        
        // Test the rest of the draw method
        when(app.checklevelover()).thenReturn(false);
        app.draw();
        verify(app).handleTankTurns();
        verify(app).checkParachuteDeployment();
        verify(app).handleParachuteDeployment();
        verify(app).handleTankFiring(any(Tank.class));
        verify(level).storeScores();
        }

    
}